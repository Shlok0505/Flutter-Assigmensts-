// ==========================================================
// OBJECT-ORIENTED PROGRAMMING: SUBCLASS 1 (INHERITANCE)
// ==========================================================

import 'library_item.dart';

/// Book class that inherits from LibraryItem.
/// Extends base functionality with book-specific attributes like author, genre, ISBN, and page count.
class Book extends LibraryItem {
  final String author;
  final String genre;
  final int pageCount;
  final String isbn;

  Book({
    required super.id,
    required super.title,
    required super.yearPublished,
    required this.author,
    required this.genre,
    required this.pageCount,
    required this.isbn,
    super.isBorrowed,
    super.borrowedBy,
    super.borrowedDate,
  });

  // Polymorphic implementation of abstract getters/methods
  @override
  String getItemType() => 'Book';

  @override
  double get dailyLateFeeRate => 0.50; // $0.50/day

  @override
  int get standardLoanPeriodDays => 21; // 3 weeks

  @override
  Map<String, dynamic> getDetails() {
    return {
      'Author': author,
      'Genre': genre,
      'Pages': pageCount,
      'ISBN': isbn,
      'Loan Period': '$standardLoanPeriodDays days',
      'Late Fee': '\$$dailyLateFeeRate/day',
    };
  }

  @override
  String toString() {
    return '${super.toString()} | Author: $author | Genre: $genre';
  }
}
