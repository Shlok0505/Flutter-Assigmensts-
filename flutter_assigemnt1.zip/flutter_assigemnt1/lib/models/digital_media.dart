// ==========================================================
// OBJECT-ORIENTED PROGRAMMING: SUBCLASS 3 (INHERITANCE)
// ==========================================================

import 'library_item.dart';

/// DigitalMedia class that inherits from LibraryItem.
/// Extends base class with digital properties (Format, File Size, Duration).
class DigitalMedia extends LibraryItem {
  final String mediaFormat; // e.g., 'Audiobook', 'E-Book', 'Video Lecture'
  final double fileSizeMb;
  final int? durationMinutes; // For audio/video formats

  DigitalMedia({
    required super.id,
    required super.title,
    required super.yearPublished,
    required this.mediaFormat,
    required this.fileSizeMb,
    this.durationMinutes,
    super.isBorrowed,
    super.borrowedBy,
    super.borrowedDate,
  });

  @override
  String getItemType() => 'Digital Media';

  @override
  double get dailyLateFeeRate => 0.10; // $0.10/day

  @override
  int get standardLoanPeriodDays => 14; // 2 weeks

  @override
  Map<String, dynamic> getDetails() {
    return {
      'Format': mediaFormat,
      'Size': '${fileSizeMb.toStringAsFixed(1)} MB',
      'Duration': durationMinutes != null ? '$durationMinutes mins' : 'N/A',
      'Loan Period': '$standardLoanPeriodDays days',
      'Late Fee': '\$$dailyLateFeeRate/day',
    };
  }

  @override
  String toString() {
    return '${super.toString()} | Format: $mediaFormat | Size: ${fileSizeMb}MB';
  }
}
