// ==========================================================
// OBJECT-ORIENTED PROGRAMMING: BASE CLASS (INHERITANCE)
// ==========================================================

import 'member.dart';

/// Base abstract class representing any item that can be managed in the library.
/// Demonstrates OOP concepts:
/// - Encapsulation (controlled mutable state with getters)
/// - Abstraction (abstract method declarations)
/// - Inheritance (base class for Book, Magazine, DigitalMedia)
/// - Polymorphism (runtime method dispatching)
abstract class LibraryItem {
  // Immutable public fields
  final String id;
  final String title;
  final int yearPublished;

  // Mutable loan state fields
  bool isBorrowed;
  Member? borrowedBy;
  DateTime? borrowedDate;

  /// Base constructor
  LibraryItem({
    required this.id,
    required this.title,
    required this.yearPublished,
    this.isBorrowed = false,
    this.borrowedBy,
    this.borrowedDate,
  });

  /// Abstract method to be overridden by subclasses (Polymorphism)
  String getItemType();

  /// Abstract method returning a map of type-specific attributes
  Map<String, dynamic> getDetails();

  /// Abstract method to calculate late fee per day (varies by item type)
  double get dailyLateFeeRate;

  /// Standard loan period in days (polymorphic property)
  int get standardLoanPeriodDays;

  /// Method with function logic to borrow an item
  bool borrowItem(Member member) {
    if (isBorrowed) {
      return false; // Already borrowed
    }
    isBorrowed = true;
    borrowedBy = member;
    borrowedDate = DateTime.now();
    member.addBorrowedItem(this);
    return true;
  }

  /// Method with function logic to return an item
  bool returnItem() {
    if (!isBorrowed) {
      return false; // Was not borrowed
    }
    borrowedBy?.removeBorrowedItem(this);
    isBorrowed = false;
    borrowedBy = null;
    borrowedDate = null;
    return true;
  }

  /// Function to calculate overdue fee based on days overdue
  double calculateLateFee({required int daysOverdue}) {
    if (daysOverdue <= 0) return 0.0;
    return daysOverdue * dailyLateFeeRate;
  }

  /// Overridden toString method for console output & debugging
  @override
  String toString() {
    return '[$getItemType()] ID: $id | "$title" ($yearPublished) - '
        'Status: ${isBorrowed ? "Borrowed by ${borrowedBy?.name}" : "Available"}';
  }
}
