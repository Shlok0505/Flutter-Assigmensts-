// ==========================================================
// OBJECT-ORIENTED PROGRAMMING: SUBCLASS 2 (INHERITANCE)
// ==========================================================

import 'library_item.dart';

/// Magazine class that inherits from LibraryItem.
/// Extends base class with issue number, publisher, and edition month.
class Magazine extends LibraryItem {
  final int issueNumber;
  final String publisher;
  final String month;

  Magazine({
    required super.id,
    required super.title,
    required super.yearPublished,
    required this.issueNumber,
    required this.publisher,
    required this.month,
    super.isBorrowed,
    super.borrowedBy,
    super.borrowedDate,
  });

  @override
  String getItemType() => 'Magazine';

  @override
  double get dailyLateFeeRate => 0.25; // $0.25/day

  @override
  int get standardLoanPeriodDays => 7; // 1 week

  @override
  Map<String, dynamic> getDetails() {
    return {
      'Publisher': publisher,
      'Issue #': issueNumber,
      'Month': month,
      'Loan Period': '$standardLoanPeriodDays days',
      'Late Fee': '\$$dailyLateFeeRate/day',
    };
  }

  @override
  String toString() {
    return '${super.toString()} | Issue #$issueNumber | Pub: $publisher ($month)';
  }
}
