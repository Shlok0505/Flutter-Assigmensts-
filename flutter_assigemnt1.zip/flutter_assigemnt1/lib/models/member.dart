import 'library_item.dart';

/// Class representing a Library Member (OOP Class)
class Member {
  // Instance variables
  final String id;
  final String name;
  final String email;
  final String membershipType; // e.g. 'Student', 'Faculty', 'Regular'
  final List<LibraryItem> _borrowedItems = [];

  Member({
    required this.id,
    required this.name,
    required this.email,
    this.membershipType = 'Regular',
  });

  // Getter for borrowed items list (read-only view)
  List<LibraryItem> get borrowedItems => List.unmodifiable(_borrowedItems);

  int get borrowedCount => _borrowedItems.length;

  /// Function to associate borrowed item
  void addBorrowedItem(LibraryItem item) {
    if (!_borrowedItems.contains(item)) {
      _borrowedItems.add(item);
    }
  }

  /// Function to remove borrowed item
  void removeBorrowedItem(LibraryItem item) {
    _borrowedItems.remove(item);
  }

  @override
  String toString() {
    return 'Member: $name ($id) | Plan: $membershipType | Active Loans: ${_borrowedItems.length}';
  }
}
