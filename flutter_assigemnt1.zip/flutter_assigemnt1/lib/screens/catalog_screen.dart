import 'package:flutter/material.dart';
import '../services/library_service.dart';
import '../widgets/item_card.dart';
import '../widgets/add_item_dialog.dart';

class CatalogScreen extends StatefulWidget {
  final LibraryService libraryService;

  const CatalogScreen({super.key, required this.libraryService});

  @override
  State<CatalogScreen> createState() => _CatalogScreenState();
}

class _CatalogScreenState extends State<CatalogScreen> {
  String _selectedFilter = 'All';
  String _searchQuery = '';
  bool? _availabilityFilter; // null = all, true = available only, false = borrowed only
  final _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Demonstrating Function + Loop search query execution
    final filteredItems = widget.libraryService.searchItems(
      query: _searchQuery,
      filterType: _selectedFilter,
      onlyAvailable: _availabilityFilter,
    );

    final counts = widget.libraryService.getItemTypeCounts();

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // Quick Stats Banner
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // KPI Cards Row
                  Row(
                    children: [
                      _buildStatCard(
                        title: 'Total Items',
                        value: widget.libraryService.items.length.toString(),
                        icon: Icons.inventory_2_rounded,
                        color: Colors.blue,
                      ),
                      const SizedBox(width: 8),
                      _buildStatCard(
                        title: 'Available',
                        value: widget.libraryService.availableItemsCount.toString(),
                        icon: Icons.check_circle_rounded,
                        color: Colors.green,
                      ),
                      const SizedBox(width: 8),
                      _buildStatCard(
                        title: 'Checked Out',
                        value: widget.libraryService.borrowedItemsCount.toString(),
                        icon: Icons.access_time_filled_rounded,
                        color: Colors.amber.shade800,
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // Search Bar
                  TextField(
                    controller: _searchController,
                    decoration: InputDecoration(
                      hintText: 'Search items by title, author, ID, genre...',
                      prefixIcon: const Icon(Icons.search),
                      suffixIcon: _searchQuery.isNotEmpty
                          ? IconButton(
                              icon: const Icon(Icons.clear),
                              onPressed: () {
                                _searchController.clear();
                                setState(() => _searchQuery = '');
                              },
                            )
                          : null,
                      filled: true,
                      fillColor: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: 0.4),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: BorderSide.none,
                      ),
                    ),
                    onChanged: (val) {
                      setState(() => _searchQuery = val);
                    },
                  ),
                  const SizedBox(height: 12),

                  // Category Filter Chips (Polymorphic classes filter)
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        _buildFilterChip('All', widget.libraryService.items.length),
                        const SizedBox(width: 8),
                        _buildFilterChip('Book', counts['Book'] ?? 0),
                        const SizedBox(width: 8),
                        _buildFilterChip('Magazine', counts['Magazine'] ?? 0),
                        const SizedBox(width: 8),
                        _buildFilterChip('Digital Media', counts['Digital Media'] ?? 0),
                        const SizedBox(width: 12),
                        const Text('|', style: TextStyle(color: Colors.grey)),
                        const SizedBox(width: 12),
                        FilterChip(
                          label: const Text('Available Only'),
                          selected: _availabilityFilter == true,
                          onSelected: (selected) {
                            setState(() {
                              _availabilityFilter = selected ? true : null;
                            });
                          },
                        ),
                        const SizedBox(width: 8),
                        FilterChip(
                          label: const Text('Checked Out'),
                          selected: _availabilityFilter == false,
                          onSelected: (selected) {
                            setState(() {
                              _availabilityFilter = selected ? false : null;
                            });
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Items List Header
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Showing ${filteredItems.length} items',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                  TextButton.icon(
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (ctx) => AddItemDialog(
                          onAddItem: (newItem) {
                            widget.libraryService.addItem(newItem);
                          },
                        ),
                      );
                    },
                    icon: const Icon(Icons.add, size: 18),
                    label: const Text('Add Item'),
                  ),
                ],
              ),
            ),
          ),

          // Items list rendering
          if (filteredItems.isEmpty)
            SliverFillRemaining(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.search_off_rounded, size: 64, color: Colors.grey.shade400),
                    const SizedBox(height: 12),
                    Text(
                      'No matching library items found',
                      style: TextStyle(fontSize: 16, color: Colors.grey.shade600),
                    ),
                  ],
                ),
              ),
            )
          else
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  final item = filteredItems[index];
                  return ItemCard(
                    item: item,
                    members: widget.libraryService.members,
                    onBorrow: (itemId, memberId) {
                      widget.libraryService.borrowItem(itemId: itemId, memberId: memberId);
                    },
                    onReturn: (itemId, daysLate) {
                      widget.libraryService.returnItem(itemId: itemId, daysLate: daysLate);
                    },
                  );
                },
                childCount: filteredItems.length,
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildStatCard({
    required String title,
    required String value,
    required IconData icon,
    required Color color,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withValues(alpha: 0.2)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  title,
                  style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: color),
                ),
                Icon(icon, size: 16, color: color),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              value,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterChip(String label, int count) {
    final isSelected = _selectedFilter == label;
    return ChoiceChip(
      label: Text('$label ($count)'),
      selected: isSelected,
      onSelected: (selected) {
        if (selected) {
          setState(() => _selectedFilter = label);
        }
      },
    );
  }
}
