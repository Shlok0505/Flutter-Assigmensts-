import 'package:flutter/material.dart';
import '../services/library_service.dart';

class ConsoleLogScreen extends StatelessWidget {
  final LibraryService libraryService;

  const ConsoleLogScreen({super.key, required this.libraryService});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          // Action Buttons Bar
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                FilledButton.tonalIcon(
                  onPressed: () {
                    libraryService.simulateOverdueAudit();
                  },
                  icon: const Icon(Icons.play_arrow_rounded, size: 18),
                  label: const Text('Run Loop Audit (while)'),
                ),
                FilledButton.tonalIcon(
                  onPressed: () {
                    libraryService.logMessage(
                      'Polymorphism Check: Calculating daily late fees -> '
                      'Book: \$0.50/day | Magazine: \$0.25/day | Digital Media: \$0.10/day',
                    );
                  },
                  icon: const Icon(Icons.code_rounded, size: 18),
                  label: const Text('Check Polymorphism'),
                ),
                OutlinedButton.icon(
                  onPressed: () {
                    libraryService.clearLogs();
                  },
                  icon: const Icon(Icons.delete_sweep_outlined, size: 18),
                  label: const Text('Clear Output'),
                ),
              ],
            ),
          ),

          // Code Concept summary banner
          ExpansionTile(
            leading: const Icon(Icons.school_rounded, color: Colors.indigo),
            title: const Text(
              'Dart Concepts Implemented in this Project',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
            ),
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                color: Colors.indigo.shade50.withValues(alpha: 0.4),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _ConceptRow(
                      concept: '1. Variables',
                      desc: 'Primitives (int, double, String, bool), DateTime, nullable types, and List/Map collections in state.',
                    ),
                    _ConceptRow(
                      concept: '2. OOP & Inheritance',
                      desc: 'Base class LibraryItem inherited by Book, Magazine, & DigitalMedia with polymorphic getDetails() and late fee rules.',
                    ),
                    _ConceptRow(
                      concept: '3. Functions',
                      desc: 'Named & optional params, arrow functions (=>), higher-order functions (.where, .map), and callback handlers.',
                    ),
                    _ConceptRow(
                      concept: '4. Loops',
                      desc: 'Traditional indexed for loop, for-in collection iterations, and while loop overdue auditing.',
                    ),
                  ],
                ),
              ),
            ],
          ),

          const Divider(height: 1),

          // Terminal Header
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            color: const Color(0xFF1E1E1E),
            child: Row(
              children: [
                const Icon(Icons.terminal_rounded, color: Colors.greenAccent, size: 18),
                const SizedBox(width: 8),
                const Text(
                  'Dart System Console & Execution Stream',
                  style: TextStyle(
                    color: Colors.white,
                    fontFamily: 'monospace',
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                  ),
                ),
                const Spacer(),
                Text(
                  '${libraryService.consoleLogs.length} logs',
                  style: const TextStyle(color: Colors.grey, fontSize: 12, fontFamily: 'monospace'),
                ),
              ],
            ),
          ),

          // Terminal Console Area
          Expanded(
            child: Container(
              color: const Color(0xFF181818),
              padding: const EdgeInsets.all(12),
              child: libraryService.consoleLogs.isEmpty
                  ? const Center(
                      child: Text(
                        'Console stream is ready. Perform actions to view live logs.',
                        style: TextStyle(color: Colors.grey, fontFamily: 'monospace'),
                      ),
                    )
                  : ListView.builder(
                      itemCount: libraryService.consoleLogs.length,
                      itemBuilder: (context, index) {
                        final log = libraryService.consoleLogs[index];
                        Color logColor = const Color(0xFFE0E0E0);

                        if (log.contains('ERROR')) {
                          logColor = Colors.redAccent;
                        } else if (log.contains('WARNING') || log.contains('LATE FEE')) {
                          logColor = Colors.amberAccent;
                        } else if (log.contains('SUCCESS') || log.contains('Added')) {
                          logColor = Colors.greenAccent;
                        } else if (log.contains('---')) {
                          logColor = Colors.cyanAccent;
                        }

                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 2),
                          child: SelectableText(
                            log,
                            style: TextStyle(
                              color: logColor,
                              fontFamily: 'monospace',
                              fontSize: 12.5,
                              height: 1.4,
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ConceptRow extends StatelessWidget {
  final String concept;
  final String desc;

  const _ConceptRow({required this.concept, required this.desc});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: RichText(
        text: TextSpan(
          style: const TextStyle(color: Colors.black87, fontSize: 13),
          children: [
            TextSpan(
              text: '$concept: ',
              style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.indigo),
            ),
            TextSpan(text: desc),
          ],
        ),
      ),
    );
  }
}
