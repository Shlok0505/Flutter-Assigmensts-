import 'package:flutter/material.dart';
import '../services/library_service.dart';
import 'catalog_screen.dart';
import 'members_screen.dart';
import 'console_log_screen.dart';
import '../widgets/add_item_dialog.dart';

class HomeScreen extends StatefulWidget {
  final LibraryService libraryService;

  const HomeScreen({super.key, required this.libraryService});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    final screens = [
      CatalogScreen(libraryService: widget.libraryService),
      MembersScreen(libraryService: widget.libraryService),
      ConsoleLogScreen(libraryService: widget.libraryService),
    ];

    final titles = [
      'Library Catalog',
      'Member Directory',
      'System Console & OOP',
    ];

    return AnimatedBuilder(
      animation: widget.libraryService,
      builder: (context, _) {
        return Scaffold(
          appBar: AppBar(
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  titles[_currentIndex],
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 19),
                ),
                Text(
                  widget.libraryService.libraryName,
                  style: TextStyle(
                    fontSize: 12,
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
            actions: [
              // Late Fee Summary Indicator
              if (widget.libraryService.totalLateFeesCollected > 0)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: Chip(
                    avatar: const Icon(Icons.account_balance_wallet, size: 14, color: Colors.green),
                    label: Text(
                      'Fees: \$${widget.libraryService.totalLateFeesCollected.toStringAsFixed(2)}',
                      style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold),
                    ),
                    backgroundColor: Colors.green.shade50,
                  ),
                ),
              IconButton(
                icon: const Icon(Icons.info_outline_rounded),
                tooltip: 'About System',
                onPressed: () => _showAboutDialog(context),
              ),
            ],
          ),
          body: screens[_currentIndex],
          bottomNavigationBar: NavigationBar(
            selectedIndex: _currentIndex,
            onDestinationSelected: (idx) {
              setState(() => _currentIndex = idx);
            },
            destinations: [
              NavigationDestination(
                icon: const Icon(Icons.local_library_outlined),
                selectedIcon: const Icon(Icons.local_library_rounded),
                label: 'Catalog (${widget.libraryService.items.length})',
              ),
              NavigationDestination(
                icon: const Icon(Icons.people_outline_rounded),
                selectedIcon: const Icon(Icons.people_rounded),
                label: 'Members (${widget.libraryService.members.length})',
              ),
              NavigationDestination(
                icon: const Icon(Icons.terminal_outlined),
                selectedIcon: const Icon(Icons.terminal_rounded),
                label: 'Console & Logs',
              ),
            ],
          ),
          floatingActionButton: _currentIndex == 0
              ? FloatingActionButton.extended(
                  onPressed: () {
                    showDialog(
                      context: context,
                      builder: (ctx) => AddItemDialog(
                        onAddItem: (newItem) {
                          widget.libraryService.addItem(newItem);
                        },
                      ),
                    );
                  },
                  icon: const Icon(Icons.add_rounded),
                  label: const Text('Add Item'),
                )
              : null,
        );
      },
    );
  }

  void _showAboutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.local_library_rounded, color: Colors.indigo),
            SizedBox(width: 8),
            Text('Library System Info'),
          ],
        ),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'A complete Dart & Flutter application demonstrating:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text('• Variables (Primitives, DateTime, Collections, Nullable types)'),
            Text('• OOP Inheritance (LibraryItem -> Book, Magazine, DigitalMedia)'),
            Text('• Polymorphism & Encapsulation'),
            Text('• Functions (Named params, Arrow syntax, Higher-order functions)'),
            Text('• Loops (for, for-in, while, forEach)'),
            SizedBox(height: 12),
            Text(
              'Tip: You can also run the CLI script directly using:\ndart run bin/console_demo.dart',
              style: TextStyle(fontFamily: 'monospace', fontSize: 12, color: Colors.indigo),
            ),
          ],
        ),
        actions: [
          FilledButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Got it'),
          ),
        ],
      ),
    );
  }
}
