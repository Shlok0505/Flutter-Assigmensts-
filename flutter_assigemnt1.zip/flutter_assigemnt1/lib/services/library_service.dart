import 'package:flutter/foundation.dart';
import '../models/library_item.dart';
import '../models/book.dart';
import '../models/magazine.dart';
import '../models/digital_media.dart';
import '../models/member.dart';

/// Service class managing library operations.
/// Extends ChangeNotifier to allow Flutter UI components to reactively rebuild.
/// Demonstrates Variables, Functions (named, optional, arrow), Loops (for, for-in, while), and OOP.
class LibraryService extends ChangeNotifier {
  // ==========================================
  // VARIABLES: State, Collections, & Statistics
  // ==========================================
  final List<LibraryItem> _items = [];
  final List<Member> _members = [];
  final List<String> _consoleLogs = [];

  // Library statistics variables
  int _totalBorrowsCount = 0;
  double _totalLateFeesCollected = 0.0;
  final String libraryName = 'Apex Central Library System';

  LibraryService() {
    _seedInitialData();
  }

  // Getters
  List<LibraryItem> get items => List.unmodifiable(_items);
  List<Member> get members => List.unmodifiable(_members);
  List<String> get consoleLogs => List.unmodifiable(_consoleLogs);
  int get totalBorrowsCount => _totalBorrowsCount;
  double get totalLateFeesCollected => _totalLateFeesCollected;

  // ==========================================
  // FUNCTIONS & SEEDING
  // ==========================================

  /// Populates the library with initial sample data using OOP polymorphism
  void _seedInitialData() {
    logMessage('--- Initializing $libraryName ---');

    // Creating Member objects
    final member1 = Member(id: 'MEM-101', name: 'Alice Walker', email: 'alice@example.com', membershipType: 'Faculty');
    final member2 = Member(id: 'MEM-102', name: 'Bob Smith', email: 'bob@example.com', membershipType: 'Student');
    final member3 = Member(id: 'MEM-103', name: 'Charlie Davis', email: 'charlie@example.com', membershipType: 'Regular');

    _members.addAll([member1, member2, member3]);

    // Creating polymorphic LibraryItem instances (Books, Magazines, DigitalMedia)
    final book1 = Book(
      id: 'BK-001',
      title: 'Clean Code: A Handbook of Agile Craftsmanship',
      yearPublished: 2008,
      author: 'Robert C. Martin',
      genre: 'Software Engineering',
      pageCount: 464,
      isbn: '978-0132350884',
    );

    final book2 = Book(
      id: 'BK-002',
      title: 'The Pragmatic Programmer',
      yearPublished: 2019,
      author: 'David Thomas & Andrew Hunt',
      genre: 'Computer Science',
      pageCount: 352,
      isbn: '978-0135957059',
    );

    final book3 = Book(
      id: 'BK-003',
      title: 'Design Patterns: Elements of Reusable Object-Oriented Software',
      yearPublished: 1994,
      author: 'Gang of Four',
      genre: 'Architecture',
      pageCount: 395,
      isbn: '978-0201633610',
    );

    final mag1 = Magazine(
      id: 'MAG-201',
      title: 'National Geographic',
      yearPublished: 2024,
      issueNumber: 842,
      publisher: 'National Geographic Partners',
      month: 'August',
    );

    final mag2 = Magazine(
      id: 'MAG-202',
      title: 'MIT Technology Review',
      yearPublished: 2024,
      issueNumber: 127,
      publisher: 'MIT',
      month: 'September',
    );

    final media1 = DigitalMedia(
      id: 'MED-301',
      title: 'Algorithms & Data Structures Masterclass',
      yearPublished: 2023,
      mediaFormat: 'Audiobook',
      fileSizeMb: 512.5,
      durationMinutes: 720,
    );

    final media2 = DigitalMedia(
      id: 'MED-302',
      title: 'Flutter & Dart Deep Dive Video Series',
      yearPublished: 2024,
      mediaFormat: 'Video Course',
      fileSizeMb: 1420.0,
      durationMinutes: 480,
    );

    _items.addAll([book1, book2, book3, mag1, mag2, media1, media2]);

    // Initial borrow actions demonstrating function calls
    book1.borrowItem(member1);
    mag1.borrowItem(member2);
    _totalBorrowsCount = 2;

    logMessage('Loaded ${_items.length} catalog items across ${_members.length} members.');
  }

  /// Appends a message to the console log stream and debug prints
  void logMessage(String message) {
    final timestamp = DateTime.now().toIso8601String().substring(11, 19);
    _consoleLogs.insert(0, '[$timestamp] $message');
    if (_consoleLogs.length > 200) {
      _consoleLogs.removeLast();
    }
    notifyListeners();
  }

  void clearLogs() {
    _consoleLogs.clear();
    logMessage('Console logs cleared.');
  }

  // ==========================================
  // CORE FUNCTIONS: ADD, BORROW, RETURN
  // ==========================================

  /// Function to add a new registered member
  void addMember(Member member) {
    _members.add(member);
    logMessage('Registered new Member: ${member.name} [${member.id}]');
    notifyListeners();
  }

  /// Function to add any polymorphic LibraryItem
  void addItem(LibraryItem item) {
    _items.add(item);
    logMessage('Added new ${item.getItemType()}: "${item.title}" [${item.id}]');
    notifyListeners();
  }

  /// Function with named and boolean parameters to borrow an item
  bool borrowItem({required String itemId, required String memberId}) {
    final item = findItemById(itemId);
    final member = findMemberById(memberId);

    if (item == null) {
      logMessage('ERROR: Item "$itemId" was not found in catalog.');
      return false;
    }
    if (member == null) {
      logMessage('ERROR: Member "$memberId" was not found in system.');
      return false;
    }

    if (item.isBorrowed) {
      logMessage('WARNING: "${item.title}" is currently unavailable (borrowed by ${item.borrowedBy?.name}).');
      return false;
    }

    final success = item.borrowItem(member);
    if (success) {
      _totalBorrowsCount++;
      logMessage('SUCCESS: ${member.name} borrowed "${item.title}" (Standard loan: ${item.standardLoanPeriodDays} days).');
      notifyListeners();
      return true;
    }
    return false;
  }

  /// Function to return an item and calculate any potential late fees
  bool returnItem({required String itemId, int daysLate = 0}) {
    final item = findItemById(itemId);
    if (item == null || !item.isBorrowed) {
      logMessage('ERROR: Item "$itemId" is not currently checked out.');
      return false;
    }

    final borrowerName = item.borrowedBy?.name ?? 'Unknown';
    final double lateFee = item.calculateLateFee(daysOverdue: daysLate);

    if (lateFee > 0) {
      _totalLateFeesCollected += lateFee;
      logMessage('LATE FEE: $borrowerName paid \$${lateFee.toStringAsFixed(2)} for $daysLate overdue day(s) on "${item.title}".');
    }

    item.returnItem();
    logMessage('SUCCESS: "$item.title" returned by $borrowerName and is now Available.');
    notifyListeners();
    return true;
  }

  // ==========================================
  // DEMONSTRATING LOOPS & SEARCH ALGORITHMS
  // ==========================================

  /// Loop 1: Traditional `for` loop with index search
  LibraryItem? findItemById(String id) {
    for (int i = 0; i < _items.length; i++) {
      if (_items[i].id.toLowerCase() == id.toLowerCase()) {
        return _items[i];
      }
    }
    return null;
  }

  /// Loop 2: `for-in` loop over collections
  Member? findMemberById(String id) {
    for (final member in _members) {
      if (member.id.toLowerCase() == id.toLowerCase()) {
        return member;
      }
    }
    return null;
  }

  /// Loop 3: `for-in` with query filtering (Functions + Loops)
  List<LibraryItem> searchItems({
    String query = '',
    String filterType = 'All',
    bool? onlyAvailable,
  }) {
    final List<LibraryItem> results = [];

    for (final item in _items) {
      // Type matching
      bool matchesType = (filterType == 'All') || (item.getItemType() == filterType);

      // Availability matching
      bool matchesAvailability = onlyAvailable == null || (onlyAvailable ? !item.isBorrowed : item.isBorrowed);

      // Text query matching across title, id, and subclasses' author/publisher
      bool matchesQuery = true;
      if (query.isNotEmpty) {
        final q = query.toLowerCase();
        final titleMatch = item.title.toLowerCase().contains(q);
        final idMatch = item.id.toLowerCase().contains(q);
        bool extraMatch = false;

        if (item is Book) {
          extraMatch = item.author.toLowerCase().contains(q) || item.genre.toLowerCase().contains(q);
        } else if (item is Magazine) {
          extraMatch = item.publisher.toLowerCase().contains(q);
        } else if (item is DigitalMedia) {
          extraMatch = item.mediaFormat.toLowerCase().contains(q);
        }

        matchesQuery = titleMatch || idMatch || extraMatch;
      }

      if (matchesType && matchesAvailability && matchesQuery) {
        results.add(item);
      }
    }

    return results;
  }

  /// Loop 4: `while` loop demonstration for simulated loan schedule analysis
  Map<String, dynamic> simulateOverdueAudit() {
    logMessage('--- Running Overdue Simulation Audit (While Loop) ---');
    int index = 0;
    int overdueCount = 0;
    double simulatedTotalFees = 0.0;

    // While loop iterating through items
    while (index < _items.length) {
      final item = _items[index];
      if (item.isBorrowed) {
        // Simulated overdue calculation of 5 days past due for audit testing
        const int simulatedOverdueDays = 5;
        final double fee = item.calculateLateFee(daysOverdue: simulatedOverdueDays);
        simulatedTotalFees += fee;
        overdueCount++;
        logMessage('Audit Check: "${item.title}" [${item.getItemType()}] -> Est. 5-day fee: \$${fee.toStringAsFixed(2)}');
      }
      index++;
    }

    logMessage('Audit Completed: $overdueCount active loans checked. Simulated penalty: \$${simulatedTotalFees.toStringAsFixed(2)}');
    return {
      'checked': index,
      'overdueCount': overdueCount,
      'estimatedPenalty': simulatedTotalFees,
    };
  }

  // ==========================================
  // HIGHER-ORDER FUNCTIONS & ARROW SYNTAX
  // ==========================================

  /// Arrow function counting available items
  int get availableItemsCount => _items.where((item) => !item.isBorrowed).length;

  /// Arrow function counting borrowed items
  int get borrowedItemsCount => _items.where((item) => item.isBorrowed).length;

  /// Higher-order function with Map grouping
  Map<String, int> getItemTypeCounts() {
    final Map<String, int> counts = {'Book': 0, 'Magazine': 0, 'Digital Media': 0};
    for (final item in _items) {
      final type = item.getItemType();
      counts[type] = (counts[type] ?? 0) + 1;
    }
    return counts;
  }
}
