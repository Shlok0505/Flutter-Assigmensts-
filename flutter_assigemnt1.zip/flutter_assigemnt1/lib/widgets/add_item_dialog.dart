import 'package:flutter/material.dart';
import '../models/library_item.dart';
import '../models/book.dart';
import '../models/magazine.dart';
import '../models/digital_media.dart';

class AddItemDialog extends StatefulWidget {
  final void Function(LibraryItem newItem) onAddItem;

  const AddItemDialog({super.key, required this.onAddItem});

  @override
  State<AddItemDialog> createState() => _AddItemDialogState();
}

class _AddItemDialogState extends State<AddItemDialog> {
  final _formKey = GlobalKey<FormState>();

  String _selectedType = 'Book';

  // Shared fields
  final _titleController = TextEditingController();
  final _yearController = TextEditingController(text: DateTime.now().year.toString());

  // Book fields
  final _authorController = TextEditingController();
  final _genreController = TextEditingController(text: 'Technology');
  final _pagesController = TextEditingController(text: '250');
  final _isbnController = TextEditingController(text: '978-0123456789');

  // Magazine fields
  final _issueController = TextEditingController(text: '101');
  final _publisherController = TextEditingController();
  final _monthController = TextEditingController(text: 'October');

  // Digital Media fields
  String _mediaFormat = 'Audiobook';
  final _fileSizeController = TextEditingController(text: '128.0');
  final _durationController = TextEditingController(text: '180');

  @override
  void dispose() {
    _titleController.dispose();
    _yearController.dispose();
    _authorController.dispose();
    _genreController.dispose();
    _pagesController.dispose();
    _isbnController.dispose();
    _issueController.dispose();
    _publisherController.dispose();
    _monthController.dispose();
    _fileSizeController.dispose();
    _durationController.dispose();
    super.dispose();
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;

    final title = _titleController.text.trim();
    final year = int.tryParse(_yearController.text.trim()) ?? DateTime.now().year;
    final idSuffix = DateTime.now().millisecondsSinceEpoch % 10000;

    LibraryItem newItem;

    if (_selectedType == 'Book') {
      newItem = Book(
        id: 'BK-$idSuffix',
        title: title,
        yearPublished: year,
        author: _authorController.text.trim(),
        genre: _genreController.text.trim(),
        pageCount: int.tryParse(_pagesController.text.trim()) ?? 100,
        isbn: _isbnController.text.trim(),
      );
    } else if (_selectedType == 'Magazine') {
      newItem = Magazine(
        id: 'MAG-$idSuffix',
        title: title,
        yearPublished: year,
        issueNumber: int.tryParse(_issueController.text.trim()) ?? 1,
        publisher: _publisherController.text.trim(),
        month: _monthController.text.trim(),
      );
    } else {
      newItem = DigitalMedia(
        id: 'DM-$idSuffix',
        title: title,
        yearPublished: year,
        mediaFormat: _mediaFormat,
        fileSizeMb: double.tryParse(_fileSizeController.text.trim()) ?? 50.0,
        durationMinutes: int.tryParse(_durationController.text.trim()),
      );
    }

    widget.onAddItem(newItem);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Container(
        constraints: const BoxConstraints(maxWidth: 500),
        padding: const EdgeInsets.all(24),
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Add New Library Item',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                // Item Type Segmented Button
                SegmentedButton<String>(
                  segments: const [
                    ButtonSegment(value: 'Book', label: Text('Book'), icon: Icon(Icons.book)),
                    ButtonSegment(value: 'Magazine', label: Text('Magazine'), icon: Icon(Icons.menu_book)),
                    ButtonSegment(value: 'Digital Media', label: Text('Digital'), icon: Icon(Icons.headphones)),
                  ],
                  selected: {_selectedType},
                  onSelectionChanged: (Set<String> newSelection) {
                    setState(() {
                      _selectedType = newSelection.first;
                    });
                  },
                ),
                const SizedBox(height: 20),

                // Shared: Title & Year
                TextFormField(
                  controller: _titleController,
                  decoration: const InputDecoration(
                    labelText: 'Item Title *',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.title),
                  ),
                  validator: (v) => v == null || v.trim().isEmpty ? 'Title is required' : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _yearController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Publication Year *',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.calendar_today),
                  ),
                  validator: (v) => v == null || int.tryParse(v) == null ? 'Enter valid year' : null,
                ),
                const SizedBox(height: 16),

                // Type-specific input fields
                if (_selectedType == 'Book') ...[
                  TextFormField(
                    controller: _authorController,
                    decoration: const InputDecoration(
                      labelText: 'Author *',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.person),
                    ),
                    validator: (v) => v == null || v.trim().isEmpty ? 'Author is required' : null,
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          controller: _genreController,
                          decoration: const InputDecoration(
                            labelText: 'Genre',
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: TextFormField(
                          controller: _pagesController,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            labelText: 'Pages',
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _isbnController,
                    decoration: const InputDecoration(
                      labelText: 'ISBN',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.qr_code),
                    ),
                  ),
                ] else if (_selectedType == 'Magazine') ...[
                  TextFormField(
                    controller: _publisherController,
                    decoration: const InputDecoration(
                      labelText: 'Publisher *',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.business),
                    ),
                    validator: (v) => v == null || v.trim().isEmpty ? 'Publisher is required' : null,
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          controller: _issueController,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            labelText: 'Issue Number',
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: TextFormField(
                          controller: _monthController,
                          decoration: const InputDecoration(
                            labelText: 'Edition Month',
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                    ],
                  ),
                ] else if (_selectedType == 'Digital Media') ...[
                  DropdownButtonFormField<String>(
                    initialValue: _mediaFormat,
                    decoration: const InputDecoration(
                      labelText: 'Format',
                      border: OutlineInputBorder(),
                    ),
                    items: ['Audiobook', 'E-Book', 'Video Lecture', 'Interactive Course']
                        .map((f) => DropdownMenuItem(value: f, child: Text(f)))
                        .toList(),
                    onChanged: (v) {
                      if (v != null) setState(() => _mediaFormat = v);
                    },
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          controller: _fileSizeController,
                          keyboardType: const TextInputType.numberWithOptions(decimal: true),
                          decoration: const InputDecoration(
                            labelText: 'File Size (MB)',
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: TextFormField(
                          controller: _durationController,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            labelText: 'Duration (Mins)',
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],

                const SizedBox(height: 24),
                FilledButton.icon(
                  onPressed: _submit,
                  icon: const Icon(Icons.add_circle_outline),
                  label: Text('Create $_selectedType'),
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
