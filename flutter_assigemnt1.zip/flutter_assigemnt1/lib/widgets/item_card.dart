import 'package:flutter/material.dart';
import '../models/library_item.dart';
import '../models/book.dart';
import '../models/magazine.dart';
import '../models/digital_media.dart';
import '../models/member.dart';

class ItemCard extends StatelessWidget {
  final LibraryItem item;
  final List<Member> members;
  final void Function(String itemId, String memberId) onBorrow;
  final void Function(String itemId, int daysLate) onReturn;

  const ItemCard({
    super.key,
    required this.item,
    required this.members,
    required this.onBorrow,
    required this.onReturn,
  });

  Color _getTypeColor(String type) {
    switch (type) {
      case 'Book':
        return Colors.indigo;
      case 'Magazine':
        return Colors.deepOrange;
      case 'Digital Media':
        return Colors.teal;
      default:
        return Colors.blueGrey;
    }
  }

  IconData _getTypeIcon(String type) {
    switch (type) {
      case 'Book':
        return Icons.auto_stories_rounded;
      case 'Magazine':
        return Icons.menu_book_rounded;
      case 'Digital Media':
        return Icons.headphones_rounded;
      default:
        return Icons.category_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final typeColor = _getTypeColor(item.getItemType());
    final typeIcon = _getTypeIcon(item.getItemType());
    final details = item.getDetails();

    return Card(
      elevation: 2,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(
          color: item.isBorrowed ? Colors.amber.shade200 : Colors.transparent,
          width: 1.5,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Top row: Type Tag & Availability Status
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: typeColor.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(typeIcon, size: 16, color: typeColor),
                      const SizedBox(width: 6),
                      Text(
                        item.getItemType(),
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: typeColor,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  '#${item.id}',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: Colors.grey.shade600,
                  ),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: item.isBorrowed ? Colors.amber.shade50 : Colors.green.shade50,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: item.isBorrowed ? Colors.amber.shade700 : Colors.green.shade600,
                      width: 1,
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        item.isBorrowed ? Icons.lock_clock_rounded : Icons.check_circle_rounded,
                        size: 14,
                        color: item.isBorrowed ? Colors.amber.shade900 : Colors.green.shade700,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        item.isBorrowed ? 'Checked Out' : 'Available',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: item.isBorrowed ? Colors.amber.shade900 : Colors.green.shade700,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // Title
            Text(
              item.title,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                letterSpacing: -0.2,
              ),
            ),
            const SizedBox(height: 4),

            // Subtitle based on subclass
            if (item is Book)
              Text(
                'By ${(item as Book).author} • ${(item as Book).genre} • ${item.yearPublished}',
                style: TextStyle(color: Colors.grey.shade700, fontSize: 14),
              )
            else if (item is Magazine)
              Text(
                'Published by ${(item as Magazine).publisher} • ${(item as Magazine).month} ${item.yearPublished}',
                style: TextStyle(color: Colors.grey.shade700, fontSize: 14),
              )
            else if (item is DigitalMedia)
              Text(
                '${(item as DigitalMedia).mediaFormat} • ${item.yearPublished}',
                style: TextStyle(color: Colors.grey.shade700, fontSize: 14),
              ),

            const Divider(height: 24),

            // Attributes Grid / Chips
            Wrap(
              spacing: 8,
              runSpacing: 6,
              children: details.entries.map((entry) {
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade100,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    '${entry.key}: ${entry.value}',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey.shade800,
                    ),
                  ),
                );
              }).toList(),
            ),

            if (item.isBorrowed) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.amber.shade50.withValues(alpha: 0.5),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.amber.shade200),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.person_pin_rounded, color: Colors.amber, size: 20),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Borrowed by: ${item.borrowedBy?.name ?? "Unknown"} (${item.borrowedBy?.membershipType ?? ""})',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: Colors.brown.shade800,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],

            const SizedBox(height: 14),

            // Action Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                if (!item.isBorrowed)
                  FilledButton.icon(
                    onPressed: () => _showBorrowDialog(context),
                    icon: const Icon(Icons.shopping_bag_outlined, size: 18),
                    label: const Text('Borrow Item'),
                    style: FilledButton.styleFrom(
                      backgroundColor: typeColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  )
                else
                  FilledButton.tonalIcon(
                    onPressed: () => _showReturnDialog(context),
                    icon: const Icon(Icons.assignment_return_rounded, size: 18),
                    label: const Text('Return Item'),
                    style: FilledButton.styleFrom(
                      foregroundColor: Colors.brown.shade900,
                      backgroundColor: Colors.amber.shade200,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showBorrowDialog(BuildContext context) {
    if (members.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No members registered to borrow items.')),
      );
      return;
    }

    String selectedMemberId = members.first.id;

    showDialog(
      context: context,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: Text('Borrow "${item.title}"'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Item: [${item.getItemType()}] #${item.id}',
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                  Text('Standard Loan: ${item.standardLoanPeriodDays} days'),
                  const SizedBox(height: 16),
                  const Text('Select Member:'),
                  const SizedBox(height: 6),
                  DropdownButtonFormField<String>(
                    initialValue: selectedMemberId,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    ),
                    items: members.map((m) {
                      return DropdownMenuItem(
                        value: m.id,
                        child: Text('${m.name} (${m.membershipType})'),
                      );
                    }).toList(),
                    onChanged: (val) {
                      if (val != null) {
                        setState(() => selectedMemberId = val);
                      }
                    },
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: const Text('Cancel'),
                ),
                FilledButton(
                  onPressed: () {
                    Navigator.pop(ctx);
                    onBorrow(item.id, selectedMemberId);
                  },
                  child: const Text('Confirm Borrow'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  void _showReturnDialog(BuildContext context) {
    int daysOverdue = 0;

    showDialog(
      context: context,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setState) {
            final double fee = item.calculateLateFee(daysOverdue: daysOverdue);

            return AlertDialog(
              title: Text('Return "${item.title}"'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Borrower: ${item.borrowedBy?.name ?? "Unknown"}'),
                  Text('Daily Late Rate: \$${item.dailyLateFeeRate}/day'),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Days Overdue:'),
                      Text(
                        '$daysOverdue day(s)',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  Slider(
                    value: daysOverdue.toDouble(),
                    min: 0,
                    max: 30,
                    divisions: 30,
                    label: '$daysOverdue days',
                    onChanged: (val) {
                      setState(() => daysOverdue = val.toInt());
                    },
                  ),
                  if (daysOverdue > 0)
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.red.shade50,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.red.shade200),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.attach_money_rounded, color: Colors.red),
                          Text(
                            'Late Fine to Collect: \$${fee.toStringAsFixed(2)}',
                            style: const TextStyle(
                              color: Colors.red,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: const Text('Cancel'),
                ),
                FilledButton(
                  onPressed: () {
                    Navigator.pop(ctx);
                    onReturn(item.id, daysOverdue);
                  },
                  child: const Text('Confirm Return'),
                ),
              ],
            );
          },
        );
      },
    );
  }
}
