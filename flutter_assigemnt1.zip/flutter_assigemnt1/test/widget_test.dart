import 'package:flutter_test/flutter_test.dart';
import 'package:library_system/main.dart';

void main() {
  testWidgets('LibraryApp smoke test', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(const LibraryApp());

    // Verify that the catalog screen loads with title.
    expect(find.text('Library Catalog'), findsOneWidget);
  });
}
