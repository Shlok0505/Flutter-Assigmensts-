import 'package:flutter/material.dart';
import 'models/user_profile.dart';
import 'services/mock_api_service.dart';
import 'state/user_controller.dart';
import 'widgets/empty_view.dart';
import 'widgets/error_view.dart';
import 'widgets/loading_view.dart';
import 'widgets/null_safety_info_dialog.dart';
import 'widgets/scenario_selector.dart';
import 'widgets/user_card.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MockApiApp());
}

/// Root Application Widget
class MockApiApp extends StatefulWidget {
  const MockApiApp({super.key});

  @override
  State<MockApiApp> createState() => _MockApiAppState();
}

class _MockApiAppState extends State<MockApiApp> {
  final UserController _controller = UserController();

  @override
  void initState() {
    super.initState();
    // Initial async fetch on startup
    _controller.loadUsers();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: _controller,
      builder: (context, _) {
        return MaterialApp(
          title: 'Dart Null Safety & Async Mock API',
          debugShowCheckedModeBanner: false,
          themeMode: _controller.isDarkMode ? ThemeMode.dark : ThemeMode.light,
          theme: ThemeData(
            useMaterial3: true,
            colorScheme: ColorScheme.fromSeed(
              seedColor: const Color(0xFF2563EB),
              brightness: Brightness.light,
            ),
            fontFamily: 'Roboto',
            cardTheme: const CardThemeData(
              surfaceTintColor: Colors.transparent,
            ),
          ),
          darkTheme: ThemeData(
            useMaterial3: true,
            colorScheme: ColorScheme.fromSeed(
              seedColor: const Color(0xFF3B82F6),
              brightness: Brightness.dark,
            ),
            fontFamily: 'Roboto',
            cardTheme: const CardThemeData(
              surfaceTintColor: Colors.transparent,
            ),
          ),
          home: HomeScreen(controller: _controller),
        );
      },
    );
  }
}

/// Main Dashboard Screen
class HomeScreen extends StatefulWidget {
  final UserController controller;

  const HomeScreen({super.key, required this.controller});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _searchFieldController = TextEditingController();

  @override
  void dispose() {
    _searchFieldController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final controller = widget.controller;

    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        scrolledUnderElevation: 2,
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: theme.colorScheme.primaryContainer,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                Icons.bolt_rounded,
                color: theme.colorScheme.primary,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Async Mock API',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                ),
                Text(
                  'Sound Null Safety & Error Handling',
                  style: TextStyle(
                    fontSize: 11,
                    color: theme.colorScheme.onSurfaceVariant,
                    fontWeight: FontWeight.normal,
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          // Null Safety Guide action button
          IconButton(
            tooltip: 'Dart Null-Safety Guide',
            icon: const Icon(Icons.help_outline_rounded),
            onPressed: () => NullSafetyInfoDialog.show(context),
          ),
          // Theme switch action
          IconButton(
            tooltip: controller.isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode',
            icon: Icon(
              controller.isDarkMode ? Icons.light_mode_outlined : Icons.dark_mode_outlined,
            ),
            onPressed: controller.toggleTheme,
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            // 1. Scenario Selector
            ScenarioSelector(
              selectedScenario: controller.currentScenario,
              onScenarioSelected: (scenario) {
                controller.setScenario(scenario);
              },
            ),

            // 2. Search & Filter Bar (Only show if not in fatal error scenario)
            _buildSearchAndFilters(context),

            // 3. Main Content Area with Pull-to-Refresh
            Expanded(
              child: RefreshIndicator(
                onRefresh: () => controller.loadUsers(),
                child: _buildBodyContent(context),
              ),
            ),

            // 4. Status Bar Footer
            _buildFooterStatusBar(context),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchAndFilters(BuildContext context) {
    final theme = Theme.of(context);
    final controller = widget.controller;

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
      child: Column(
        children: [
          // Search Input Field
          TextField(
            controller: _searchFieldController,
            decoration: InputDecoration(
              hintText: 'Search by name, username, skill or city...',
              hintStyle: TextStyle(fontSize: 13, color: theme.colorScheme.onSurfaceVariant),
              prefixIcon: const Icon(Icons.search_rounded, size: 20),
              suffixIcon: _searchFieldController.text.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.clear, size: 18),
                      onPressed: () {
                        _searchFieldController.clear();
                        controller.setSearchQuery('');
                      },
                    )
                  : null,
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              filled: true,
              fillColor: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.4),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
            ),
            style: const TextStyle(fontSize: 13),
            onChanged: (val) => controller.setSearchQuery(val),
          ),
          const SizedBox(height: 8),

          // Role Filter Chips
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: controller.availableRoles.map((role) {
                final isSelected = (controller.selectedRole == null && role == 'All') ||
                    controller.selectedRole == role;

                return Padding(
                  padding: const EdgeInsets.only(right: 6.0),
                  child: ChoiceChip(
                    label: Text(role, style: const TextStyle(fontSize: 12)),
                    selected: isSelected,
                    onSelected: (selected) {
                      if (selected) {
                        controller.setSelectedRole(role == 'All' ? null : role);
                      }
                    },
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBodyContent(BuildContext context) {
    final controller = widget.controller;
    final state = controller.state;

    return state.when(
      idle: () => const LoadingView(message: 'Initializing...'),
      loading: (message) => LoadingView(message: message),
      empty: (message) => EmptyView(
        message: message ?? 'No records found.',
        onClearFilters: () {
          _searchFieldController.clear();
          controller.clearFilters();
        },
      ),
      onError: (error, message) => ErrorView(
        error: error,
        onRetry: () => controller.retry(),
        onResetToHealthy: () {
          _searchFieldController.clear();
          controller.setScenario(MockScenario.completeData);
        },
      ),
      success: (users, message) => _buildUserList(context, users),
    );
  }

  Widget _buildUserList(BuildContext context, List<UserProfile> users) {
    return ListView.builder(
      physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
      padding: const EdgeInsets.only(top: 4, bottom: 16),
      itemCount: users.length,
      itemBuilder: (context, index) {
        final user = users[index];
        return UserCard(user: user);
      },
    );
  }

  Widget _buildFooterStatusBar(BuildContext context) {
    final theme = Theme.of(context);
    final controller = widget.controller;
    final state = controller.state;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerLowest,
        border: Border(top: BorderSide(color: theme.dividerColor.withValues(alpha: 0.15))),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: state.isSuccess
                      ? Colors.green
                      : (state.isError ? Colors.red : Colors.amber),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                'Status: ${state.status.name.toUpperCase()}',
                style: theme.textTheme.labelSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          Text(
            'Attempts: ${controller.fetchAttempts} • Sound Null Safety 🔒',
            style: theme.textTheme.labelSmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}
