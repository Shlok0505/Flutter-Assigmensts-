import '../services/api_exceptions.dart';

/// Status representation for asynchronous API states.
enum ApiStatus {
  idle,
  loading,
  success,
  empty,
  error,
}

/// Generic ApiResponse wrapper demonstrating type safety and null safety.
/// Wraps loading, success, empty, and error states.
class ApiResponse<T> {
  final ApiStatus status;
  final T? data;
  final AppException? error;
  final String? message;
  final DateTime timestamp;

  const ApiResponse._({
    required this.status,
    this.data,
    this.error,
    this.message,
    required this.timestamp,
  });

  /// Factory for Idle / Initial state
  factory ApiResponse.idle() {
    return ApiResponse._(
      status: ApiStatus.idle,
      timestamp: DateTime.now(),
    );
  }

  /// Factory for Loading state
  factory ApiResponse.loading([String? message]) {
    return ApiResponse._(
      status: ApiStatus.loading,
      message: message ?? 'Fetching data from remote service...',
      timestamp: DateTime.now(),
    );
  }

  /// Factory for Success state with non-null payload
  factory ApiResponse.success(T data, {String? message}) {
    return ApiResponse._(
      status: ApiStatus.success,
      data: data,
      message: message,
      timestamp: DateTime.now(),
    );
  }

  /// Factory for Empty state (e.g. empty list or no search results)
  factory ApiResponse.empty({String? message}) {
    return ApiResponse._(
      status: ApiStatus.empty,
      message: message ?? 'No records found matching your query.',
      timestamp: DateTime.now(),
    );
  }

  /// Factory for Error state
  factory ApiResponse.error(AppException error, {String? message}) {
    return ApiResponse._(
      status: ApiStatus.error,
      error: error,
      message: message ?? error.message,
      timestamp: DateTime.now(),
    );
  }

  // Convenient helper getters
  bool get isIdle => status == ApiStatus.idle;
  bool get isLoading => status == ApiStatus.loading;
  bool get isSuccess => status == ApiStatus.success;
  bool get isEmpty => status == ApiStatus.empty;
  bool get isError => status == ApiStatus.error;

  /// Null-safe data extractor with fallback value
  T getOrElse(T fallback) => data ?? fallback;

  /// Fold/Pattern match pattern for UI rendering
  R when<R>({
    required R Function() idle,
    required R Function(String? message) loading,
    required R Function(T data, String? message) success,
    required R Function(String? message) empty,
    required R Function(AppException error, String? message) onError,
  }) {
    switch (status) {
      case ApiStatus.idle:
        return idle();
      case ApiStatus.loading:
        return loading(message);
      case ApiStatus.success:
        return success(data as T, message);
      case ApiStatus.empty:
        return empty(message);
      case ApiStatus.error:
        return onError(error ?? const NetworkException('Unknown error'), message);
    }
  }
}
