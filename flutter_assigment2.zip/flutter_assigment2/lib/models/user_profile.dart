/// Geo-location coordinates model showcasing nullable latitude and longitude.
class GeoLocation {
  final double? latitude;
  final double? longitude;

  const GeoLocation({
    this.latitude,
    this.longitude,
  });

  factory GeoLocation.fromJson(Map<String, dynamic>? json) {
    if (json == null) return const GeoLocation();
    return GeoLocation(
      latitude: (json['lat'] as num?)?.toDouble() ??
          double.tryParse(json['lat']?.toString() ?? ''),
      longitude: (json['lng'] as num?)?.toDouble() ??
          double.tryParse(json['lng']?.toString() ?? ''),
    );
  }

  Map<String, dynamic> toJson() => {
        'lat': latitude,
        'lng': longitude,
      };

  bool get hasCoordinates => latitude != null && longitude != null;

  String get formattedCoordinates =>
      hasCoordinates ? '${latitude!.toStringAsFixed(4)}, ${longitude!.toStringAsFixed(4)}' : 'Unavailable';
}

/// Address model demonstrating nested nullable objects and safe string concatenation.
class Address {
  final String? street;
  final String? suite;
  final String? city;
  final String? zipcode;
  final GeoLocation? geo;

  const Address({
    this.street,
    this.suite,
    this.city,
    this.zipcode,
    this.geo,
  });

  factory Address.fromJson(Map<String, dynamic>? json) {
    if (json == null) return const Address();
    return Address(
      street: json['street'] as String?,
      suite: json['suite'] as String?,
      city: json['city'] as String?,
      zipcode: json['zipcode'] as String?,
      geo: json['geo'] != null ? GeoLocation.fromJson(json['geo'] as Map<String, dynamic>) : null,
    );
  }

  Map<String, dynamic> toJson() => {
        'street': street,
        'suite': suite,
        'city': city,
        'zipcode': zipcode,
        'geo': geo?.toJson(),
      };

  /// Demonstrates null-aware operations and fallback strings.
  String get fullAddress {
    final parts = [street, suite, city, zipcode].where((part) => part != null && part.isNotEmpty);
    return parts.isEmpty ? 'Address not specified' : parts.join(', ');
  }

  String get shortCity => city ?? 'Unknown Location';
}

/// Company information model with nullable fields.
class Company {
  final String? name;
  final String? catchPhrase;
  final String? bs;

  const Company({
    this.name,
    this.catchPhrase,
    this.bs,
  });

  factory Company.fromJson(Map<String, dynamic>? json) {
    if (json == null) return const Company();
    return Company(
      name: json['name'] as String?,
      catchPhrase: json['catchPhrase'] as String?,
      bs: json['bs'] as String?,
    );
  }

  Map<String, dynamic> toJson() => {
        'name': name,
        'catchPhrase': catchPhrase,
        'bs': bs,
      };

  String get displayName => name ?? 'Independent / Freelance';
}

/// Core User Profile demonstrating sound null safety in Dart:
/// - Required non-nullable fields (e.g., [id], [name], [username], [email])
/// - Nullable optional fields (e.g., [avatarUrl], [bio], [phone], [website], [rating], [role], [address], [company], [lastActive])
class UserProfile {
  // Non-nullable required fields
  final int id;
  final String name;
  final String username;
  final String email;

  // Nullable optional fields
  final String? avatarUrl;
  final String? bio;
  final String? phone;
  final String? website;
  final double? rating;
  final String? role;
  final bool? isVerified;
  final List<String>? skills;
  final Address? address;
  final Company? company;
  final DateTime? lastActive;

  const UserProfile({
    required this.id,
    required this.name,
    required this.username,
    required this.email,
    this.avatarUrl,
    this.bio,
    this.phone,
    this.website,
    this.rating,
    this.role,
    this.isVerified,
    this.skills,
    this.address,
    this.company,
    this.lastActive,
  });

  /// Factory constructor demonstrating safe JSON parsing:
  /// - Null coalescing (`??`) for defaults
  /// - Safe type casting and null checks (`as String?`, `as num?`)
  /// - Safe date parsing (`DateTime.tryParse`)
  factory UserProfile.fromJson(Map<String, dynamic> json) {
    // Required fields with defensive fallbacks if raw API data is imperfect
    final parsedId = (json['id'] as num?)?.toInt() ?? 0;
    final parsedName = (json['name'] as String?)?.trim() ?? 'Unknown User';
    final parsedUsername = (json['username'] as String?)?.trim() ?? 'unknown_user';
    final parsedEmail = (json['email'] as String?)?.trim() ?? 'no-email@domain.com';

    // Nullable fields
    final parsedAvatarUrl = json['avatarUrl'] as String?;
    final parsedBio = json['bio'] as String?;
    final parsedPhone = json['phone'] as String?;
    final parsedWebsite = json['website'] as String?;
    final parsedRating = (json['rating'] as num?)?.toDouble();
    final parsedRole = json['role'] as String?;
    final parsedIsVerified = json['isVerified'] as bool?;

    // Safe list parsing
    List<String>? parsedSkills;
    if (json['skills'] is List) {
      parsedSkills = (json['skills'] as List)
          .map((item) => item?.toString() ?? '')
          .where((s) => s.isNotEmpty)
          .toList();
    }

    // Safe nested object parsing
    final parsedAddress = json['address'] != null && json['address'] is Map<String, dynamic>
        ? Address.fromJson(json['address'] as Map<String, dynamic>)
        : null;

    final parsedCompany = json['company'] != null && json['company'] is Map<String, dynamic>
        ? Company.fromJson(json['company'] as Map<String, dynamic>)
        : null;

    // Safe DateTime parsing
    DateTime? parsedLastActive;
    if (json['lastActive'] != null) {
      parsedLastActive = DateTime.tryParse(json['lastActive'].toString());
    }

    return UserProfile(
      id: parsedId,
      name: parsedName,
      username: parsedUsername,
      email: parsedEmail,
      avatarUrl: parsedAvatarUrl,
      bio: parsedBio,
      phone: parsedPhone,
      website: parsedWebsite,
      rating: parsedRating,
      role: parsedRole,
      isVerified: parsedIsVerified,
      skills: parsedSkills,
      address: parsedAddress,
      company: parsedCompany,
      lastActive: parsedLastActive,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'username': username,
        'email': email,
        'avatarUrl': avatarUrl,
        'bio': bio,
        'phone': phone,
        'website': website,
        'rating': rating,
        'role': role,
        'isVerified': isVerified,
        'skills': skills,
        'address': address?.toJson(),
        'company': company?.toJson(),
        'lastActive': lastActive?.toIso8601String(),
      };

  // --- Null-Safe Helper Getters ---

  /// Computes initials safely from the name string.
  String get initials {
    final cleanName = name.trim();
    if (cleanName.isEmpty) return 'U';
    final parts = cleanName.split(RegExp(r'\s+'));
    if (parts.length > 1 && parts.first.isNotEmpty && parts.last.isNotEmpty) {
      return '${parts.first[0]}${parts.last[0]}'.toUpperCase();
    }
    return cleanName[0].toUpperCase();
  }

  /// Returns user's bio or a friendly fallback string using `??`.
  String get displayBio => bio ?? 'No biography provided yet. This user prefers to let their work speak for itself.';

  /// Returns user's phone or a fallback.
  String get displayPhone => phone ?? 'No contact phone provided';

  /// Returns user's website or a fallback.
  String get displayWebsite => website ?? 'No website listed';

  /// Returns the role with fallback.
  String get displayRole => role ?? 'Community Member';

  /// Safe rating string.
  String get displayRating => rating != null ? rating!.toStringAsFixed(1) : 'Unrated';

  /// Safe skills list.
  List<String> get safeSkills => skills ?? const [];

  /// Check whether avatarUrl is populated and non-empty.
  bool get hasAvatar => avatarUrl != null && avatarUrl!.trim().isNotEmpty;

  /// Check verification status safely.
  bool get verified => isVerified ?? false;

  /// Formatted last active time using null safety.
  String get displayLastActive {
    if (lastActive == null) return 'Active status unknown';
    final difference = DateTime.now().difference(lastActive!);
    if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inDays}d ago';
    }
  }

  /// CopyWith method demonstrating nullable parameter replacements.
  UserProfile copyWith({
    int? id,
    String? name,
    String? username,
    String? email,
    String? avatarUrl,
    String? bio,
    String? phone,
    String? website,
    double? rating,
    String? role,
    bool? isVerified,
    List<String>? skills,
    Address? address,
    Company? company,
    DateTime? lastActive,
  }) {
    return UserProfile(
      id: id ?? this.id,
      name: name ?? this.name,
      username: username ?? this.username,
      email: email ?? this.email,
      avatarUrl: avatarUrl ?? this.avatarUrl,
      bio: bio ?? this.bio,
      phone: phone ?? this.phone,
      website: website ?? this.website,
      rating: rating ?? this.rating,
      role: role ?? this.role,
      isVerified: isVerified ?? this.isVerified,
      skills: skills ?? this.skills,
      address: address ?? this.address,
      company: company ?? this.company,
      lastActive: lastActive ?? this.lastActive,
    );
  }
}
