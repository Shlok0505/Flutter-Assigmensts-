/// Custom exception hierarchy for the Mock API service.
/// Demonstrates sound null safety in Dart error modeling.
abstract class AppException implements Exception {
  final String message;
  final int? statusCode;
  final String code;

  const AppException(
    this.message, {
    this.statusCode,
    required this.code,
  });

  @override
  String toString() => '[$code] $message (Status: ${statusCode ?? "N/A"})';
}

/// Thrown when there is no internet connection or a socket/network failure.
class NetworkException extends AppException {
  const NetworkException([super.message = 'Unable to connect to the server. Please check your internet connection.'])
      : super(statusCode: null, code: 'NETWORK_ERROR');
}

/// Thrown when the server returns a 5xx or unhandled status error.
class ServerException extends AppException {
  const ServerException({
    String message = 'Internal server error occurred while processing the request.',
    super.statusCode = 500,
  }) : super(message, code: 'SERVER_ERROR');
}

/// Thrown when a request takes longer than the allowed threshold.
class ApiTimeoutException extends AppException {
  final Duration duration;

  const ApiTimeoutException({
    String message = 'Request timed out. The server took too long to respond.',
    this.duration = const Duration(seconds: 5),
  }) : super(message, statusCode: 408, code: 'TIMEOUT_ERROR');

  @override
  String toString() => '$message (${duration.inSeconds}s limit)';
}

/// Thrown when JSON data fails schema validation or contains malformed values.
class DataParsingException extends AppException {
  final String? failedField;

  const DataParsingException({
    required String message,
    this.failedField,
  }) : super(message, statusCode: 422, code: 'PARSE_ERROR');
}

/// Thrown when the requested resource is not found (404).
class NotFoundException extends AppException {
  const NotFoundException([super.message = 'The requested resource was not found.'])
      : super(statusCode: 404, code: 'NOT_FOUND');
}
