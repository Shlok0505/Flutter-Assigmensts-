import 'dart:async';
import 'dart:convert';
import '../models/user_profile.dart';
import 'api_exceptions.dart';

/// Available mock scenarios to test and showcase different async API responses
enum MockScenario {
  completeData(
    title: 'Complete Data',
    description: 'All fields populated. Demonstrates happy path with rich data.',
    iconName: 'check_circle',
  ),
  partialNullData(
    title: 'Nullable / Partial Data',
    description: 'Multiple fields are null (avatar, bio, phone, address). Tests null-safety fallbacks.',
    iconName: 'rule',
  ),
  networkFailure(
    title: 'Network Failure',
    description: 'Simulates connection loss (Throws NetworkException).',
    iconName: 'wifi_off',
  ),
  serverError(
    title: 'Server Error (500)',
    description: 'Simulates backend internal server failure (Throws ServerException).',
    iconName: 'error_outline',
  ),
  timeoutError(
    title: 'Timeout (408)',
    description: 'Simulates slow connection exceeding timeout limit.',
    iconName: 'timer_off',
  ),
  emptyResponse(
    title: 'Empty Response',
    description: 'Returns empty list []. Tests empty-state UI.',
    iconName: 'inbox',
  ),
  malformedJson(
    title: 'Malformed Payload',
    description: 'Simulates invalid server JSON structure to test parse error handling.',
    iconName: 'code_off',
  );

  final String title;
  final String description;
  final String iconName;

  const MockScenario({
    required this.title,
    required this.description,
    required this.iconName,
  });
}

/// Asynchronous Mock API Service
/// Utilizes Dart `Future`, `async`, `await`, and `sound null safety` to simulate remote REST API calls.
class MockApiService {
  // Configurable simulated network latency
  static const Duration defaultDelay = Duration(milliseconds: 900);

  /// Fetch users asynchronously using Future and async/await.
  /// Throws typed [AppException] subclasses on failure.
  Future<List<UserProfile>> fetchUsers({
    MockScenario scenario = MockScenario.completeData,
    Duration delay = defaultDelay,
    String? searchQuery,
    String? roleFilter,
  }) async {
    // 1. Simulate network latency asynchronously
    await Future.delayed(delay);

    // 2. Handle scenario branch
    switch (scenario) {
      case MockScenario.networkFailure:
        throw const NetworkException(
          'Network connection interrupted: SocketException (OS Error: Connection refused, errno = 61)',
        );

      case MockScenario.serverError:
        throw const ServerException(
          message: 'HTTP 500: Database cluster connection timeout in /api/v2/users',
          statusCode: 500,
        );

      case MockScenario.timeoutError:
        // Wait extra time then throw
        await Future.delayed(const Duration(milliseconds: 600));
        throw const ApiTimeoutException(
          message: 'Request aborted: Server took longer than the configured timeout duration (5000ms).',
          duration: Duration(seconds: 5),
        );

      case MockScenario.emptyResponse:
        return <UserProfile>[];

      case MockScenario.malformedJson:
        // Intentionally malformed JSON string that fails parsing
        const rawMalformedJson = '''
        [
          {"id": "NOT_AN_INT", "name": null, "corrupted": true}
        ]
        ''';
        try {
          final decoded = json.decode(rawMalformedJson) as List<dynamic>;
          // Simulate strict schema failure
          if (decoded.first['id'] is! int) {
            throw const DataParsingException(
              message: 'JSON Deserialization failed: Expected integer for "id", received String "NOT_AN_INT"',
              failedField: 'id',
            );
          }
          return [];
        } catch (e) {
          if (e is AppException) rethrow;
          throw DataParsingException(
            message: 'Unexpected parse failure: ${e.toString()}',
          );
        }

      case MockScenario.partialNullData:
        return _filterAndSearch(_getPartialNullUsers(), searchQuery, roleFilter);

      case MockScenario.completeData:
        return _filterAndSearch(_getCompleteUsers(), searchQuery, roleFilter);
    }
  }

  /// Helper filter for search query and role filter with null-safe operators
  List<UserProfile> _filterAndSearch(
    List<UserProfile> users,
    String? searchQuery,
    String? roleFilter,
  ) {
    var result = List<UserProfile>.from(users);

    // Filter by role if specified
    if (roleFilter != null && roleFilter.isNotEmpty && roleFilter != 'All') {
      result = result.where((u) => u.role?.toLowerCase() == roleFilter.toLowerCase()).toList();
    }

    // Filter by search query if provided
    if (searchQuery != null && searchQuery.trim().isNotEmpty) {
      final query = searchQuery.trim().toLowerCase();
      result = result.where((u) {
        final matchesName = u.name.toLowerCase().contains(query);
        final matchesUsername = u.username.toLowerCase().contains(query);
        final matchesEmail = u.email.toLowerCase().contains(query);
        final matchesRole = u.role?.toLowerCase().contains(query) ?? false;
        final matchesCity = u.address?.city?.toLowerCase().contains(query) ?? false;
        final matchesSkill = u.skills?.any((s) => s.toLowerCase().contains(query)) ?? false;

        return matchesName || matchesUsername || matchesEmail || matchesRole || matchesCity || matchesSkill;
      }).toList();
    }

    return result;
  }

  /// Complete dataset with all nullable fields populated
  List<UserProfile> _getCompleteUsers() {
    return [
      UserProfile(
        id: 101,
        name: 'Alexandria Vance',
        username: 'alex.vance',
        email: 'alex.vance@flutterdev.io',
        avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=250&auto=format&fit=crop&q=80',
        bio: 'Senior Flutter & Dart Architect passionate about reactive architecture, state management, and sound null safety.',
        phone: '+1 (555) 234-5678',
        website: 'https://alexvance.dev',
        rating: 4.9,
        role: 'Mobile Architect',
        isVerified: true,
        skills: ['Flutter', 'Dart', 'Async/Await', 'Null Safety', 'Clean Architecture', 'Bloc'],
        lastActive: DateTime.now().subtract(const Duration(minutes: 12)),
        address: const Address(
          street: '742 Evergreen Terrace',
          suite: 'Suite 400',
          city: 'San Francisco',
          zipcode: '94107',
          geo: GeoLocation(latitude: 37.7749, longitude: -122.4194),
        ),
        company: const Company(
          name: 'Nexus Cloud Technologies',
          catchPhrase: 'Empowering cross-platform mobile scale',
          bs: 'enterprise app solutions',
        ),
      ),
      UserProfile(
        id: 102,
        name: 'Marcus Chen',
        username: 'marcus_c',
        email: 'marcus.chen@techcorp.com',
        avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=250&auto=format&fit=crop&q=80',
        bio: 'Backend & Systems Engineer specializing in distributed microservices, REST APIs, and GraphQL.',
        phone: '+1 (555) 876-5432',
        website: 'https://marcuschen.tech',
        rating: 4.8,
        role: 'Backend Engineer',
        isVerified: true,
        skills: ['Dart Server', 'Go', 'PostgreSQL', 'Docker', 'REST APIs'],
        lastActive: DateTime.now().subtract(const Duration(minutes: 45)),
        address: const Address(
          street: '100 Innovation Way',
          suite: 'Floor 8',
          city: 'Seattle',
          zipcode: '98101',
          geo: GeoLocation(latitude: 47.6062, longitude: -122.3321),
        ),
        company: const Company(
          name: 'Apex Data Systems',
          catchPhrase: 'Real-time scalable cloud pipelines',
          bs: 'scalable analytics infrastructure',
        ),
      ),
      UserProfile(
        id: 103,
        name: 'Elena Rostova',
        username: 'elena_design',
        email: 'elena.rostova@creativeui.org',
        avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=250&auto=format&fit=crop&q=80',
        bio: 'Product Designer & UI/UX Specialist crafting beautiful Material 3 interfaces, typography systems, and micro-interactions.',
        phone: '+1 (555) 432-1098',
        website: 'https://elenarostova.design',
        rating: 5.0,
        role: 'Lead UI/UX Designer',
        isVerified: true,
        skills: ['Figma', 'Material Design 3', 'Flutter Animations', 'Design Systems', 'Prototyping'],
        lastActive: DateTime.now().subtract(const Duration(hours: 2)),
        address: const Address(
          street: '450 Art Avenue',
          suite: 'Studio 12',
          city: 'New York',
          zipcode: '10001',
          geo: GeoLocation(latitude: 40.7128, longitude: -74.0060),
        ),
        company: const Company(
          name: 'Lumina Studio',
          catchPhrase: 'Designing immersive digital experiences',
          bs: 'brand identity & UI engineering',
        ),
      ),
      UserProfile(
        id: 104,
        name: 'Liam O\'Connor',
        username: 'liam_devops',
        email: 'liam.oconnor@infraflow.net',
        avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=250&auto=format&fit=crop&q=80',
        bio: 'DevOps & Reliability Engineer focusing on CI/CD automation for Flutter apps, fastlane deployments, and cloud monitoring.',
        phone: '+1 (555) 901-2345',
        website: 'https://liam-infra.net',
        rating: 4.7,
        role: 'DevOps Engineer',
        isVerified: false,
        skills: ['Fastlane', 'GitHub Actions', 'Kubernetes', 'Terraform', 'AWS'],
        lastActive: DateTime.now().subtract(const Duration(hours: 5)),
        address: const Address(
          street: '320 Highland Blvd',
          suite: 'Suite 2B',
          city: 'Austin',
          zipcode: '78701',
          geo: GeoLocation(latitude: 30.2672, longitude: -97.7431),
        ),
        company: const Company(
          name: 'InfraFlow DevOps',
          catchPhrase: 'Seamless automated deployments',
          bs: 'cloud reliability engineering',
        ),
      ),
      UserProfile(
        id: 105,
        name: 'Priya Sharma',
        username: 'priya_ai',
        email: 'priya.sharma@mlinnovations.com',
        avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=250&auto=format&fit=crop&q=80',
        bio: 'AI/ML Engineer integrating on-device neural models, TensorFlow Lite, and generative AI features into mobile apps.',
        phone: '+1 (555) 345-6789',
        website: 'https://priyasharma.ai',
        rating: 4.95,
        role: 'AI Researcher',
        isVerified: true,
        skills: ['TensorFlow Lite', 'PyTorch', 'Dart FFI', 'On-Device AI', 'Python'],
        lastActive: DateTime.now().subtract(const Duration(hours: 1)),
        address: const Address(
          street: '55 Research Parkway',
          suite: 'Lab 4',
          city: 'Boston',
          zipcode: '02115',
          geo: GeoLocation(latitude: 42.3601, longitude: -71.0589),
        ),
        company: const Company(
          name: 'Cognitive Intelligence Labs',
          catchPhrase: 'Next generation edge AI algorithms',
          bs: 'machine learning modeling',
        ),
      ),
    ];
  }

  /// Partial/Null dataset containing diverse null and missing fields
  /// Used to demonstrate how null-aware operators (`??`, `?.`, `??=`) safeguard the UI
  List<UserProfile> _getPartialNullUsers() {
    return [
      const UserProfile(
        id: 201,
        name: 'Jordan Rivera',
        username: 'jordan_r',
        email: 'jordan.rivera@example.com',
        avatarUrl: null, // Null Avatar -> triggers initials fallback
        bio: null, // Null Bio -> triggers "No bio provided" fallback
        phone: null, // Null Phone -> triggers fallback chip
        website: null, // Null Website
        rating: null, // Null Rating -> triggers "Unrated"
        role: null, // Null Role -> triggers "Community Member"
        isVerified: null, // Null bool -> defaults to false safely
        skills: null, // Null Skills list -> defaults to empty list safely
        address: null, // Null Address -> safely handled by ?. operator
        company: null, // Null Company
        lastActive: null, // Null Date -> safely handled
      ),
      UserProfile(
        id: 202,
        name: 'Samantha Wu',
        username: 'sam_wu',
        email: 'sam.wu@designcraft.co',
        avatarUrl: null, // Missing avatar
        bio: 'UI enthusiast exploring Dart sound null safety in modern Flutter applications.',
        phone: '+1 (555) 111-2233',
        website: null, // Missing website
        rating: 4.6,
        role: 'Lead UI/UX Designer',
        isVerified: true,
        skills: ['UI Design', 'Figma'],
        lastActive: DateTime.now().subtract(const Duration(minutes: 30)),
        address: const Address(
          street: '12 Maple Court',
          city: 'Chicago',
          suite: null, // Missing suite
          zipcode: null, // Missing zipcode
          geo: null, // Missing coordinates
        ),
        company: null, // Missing company
      ),
      UserProfile(
        id: 203,
        name: 'Devon Knight',
        username: 'devon_k',
        email: 'devon.k@backendhub.io',
        avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=250&auto=format&fit=crop&q=80',
        bio: null, // Missing bio
        phone: null, // Missing phone
        website: 'https://devonknight.dev',
        rating: null, // Unrated
        role: 'Backend Engineer',
        isVerified: null, // Null verification
        skills: ['SQL', 'Dart', 'Docker'],
        lastActive: null,
        address: null, // Missing address
        company: const Company(
          name: 'Async Services LLC',
          catchPhrase: null, // Missing catchphrase
          bs: null,
        ),
      ),
      UserProfile(
        id: 204,
        name: 'Zoe Martinez',
        username: 'zoe_m',
        email: 'zoe.martinez@cloudlab.org',
        avatarUrl: null,
        bio: 'Building reliable and resilient Flutter apps with defensive coding and null safety.',
        phone: '+1 (555) 999-8877',
        website: 'https://zoe-martinez.org',
        rating: 4.85,
        role: 'Mobile Architect',
        isVerified: false,
        skills: null, // Missing skills
        lastActive: DateTime.now().subtract(const Duration(days: 2)),
        address: const Address(
          street: null,
          suite: null,
          city: 'Denver',
          zipcode: '80202',
          geo: GeoLocation(latitude: 39.7392, longitude: -104.9903),
        ),
        company: const Company(
          name: null, // Null company name
          catchPhrase: 'Automating everything',
          bs: null,
        ),
      ),
    ];
  }
}
