import 'package:flutter/foundation.dart';
import '../models/api_response.dart';
import '../models/user_profile.dart';
import '../services/api_exceptions.dart';
import '../services/mock_api_service.dart';

/// State management controller managing users API lifecycle.
/// Demonstrates async/await, try/catch/on, Future handling, and null safety.
class UserController extends ChangeNotifier {
  final MockApiService _apiService;

  UserController({MockApiService? apiService})
      : _apiService = apiService ?? MockApiService();

  // Internal reactive states
  ApiResponse<List<UserProfile>> _state = ApiResponse.idle();
  MockScenario _currentScenario = MockScenario.completeData;
  String _searchQuery = '';
  String? _selectedRole;
  bool _isDarkMode = true;
  int _fetchAttempts = 0;
  DateTime? _lastFetchTime;

  // Public getters
  ApiResponse<List<UserProfile>> get state => _state;
  MockScenario get currentScenario => _currentScenario;
  String get searchQuery => _searchQuery;
  String? get selectedRole => _selectedRole;
  bool get isDarkMode => _isDarkMode;
  int get fetchAttempts => _fetchAttempts;
  DateTime? get lastFetchTime => _lastFetchTime;

  /// Available roles extracted dynamically or provided statically
  List<String> get availableRoles => const [
        'All',
        'Mobile Architect',
        'Backend Engineer',
        'Lead UI/UX Designer',
        'DevOps Engineer',
        'AI Researcher',
      ];

  /// Core async method to fetch data using `Future`, `async`/`await`, and error catching.
  Future<void> loadUsers({MockScenario? scenario}) async {
    // 1. Update scenario if supplied
    if (scenario != null) {
      _currentScenario = scenario;
    }

    _fetchAttempts++;
    _state = ApiResponse.loading(
      'Connecting to API (Scenario: ${_currentScenario.title})...',
    );
    notifyListeners();

    try {
      // 2. Await asynchronous Future from service
      final results = await _apiService.fetchUsers(
        scenario: _currentScenario,
        searchQuery: _searchQuery,
        roleFilter: _selectedRole,
      );

      _lastFetchTime = DateTime.now();

      // 3. Handle empty vs success states
      if (results.isEmpty) {
        _state = ApiResponse.empty(
          message: _searchQuery.isNotEmpty || (_selectedRole != null && _selectedRole != 'All')
              ? 'No users match your filter criteria ("${_searchQuery.isNotEmpty ? _searchQuery : _selectedRole}").'
              : 'No user records are currently available on the server.',
        );
      } else {
        _state = ApiResponse.success(
          results,
          message: 'Successfully loaded ${results.length} user profile${results.length == 1 ? '' : 's'}.',
        );
      }
    } on AppException catch (e) {
      // Catch specific typed domain exceptions
      _state = ApiResponse.error(e);
    } catch (e) {
      // Fallback for unexpected runtime errors
      _state = ApiResponse.error(
        NetworkException('An unexpected error occurred: ${e.toString()}'),
      );
    } finally {
      notifyListeners();
    }
  }

  /// Change active scenario and re-fetch
  Future<void> setScenario(MockScenario newScenario) async {
    if (_currentScenario == newScenario && !_state.isError) return;
    _currentScenario = newScenario;
    await loadUsers();
  }

  /// Update search query and reload data
  Future<void> setSearchQuery(String query) async {
    _searchQuery = query;
    await loadUsers();
  }

  /// Update role filter and reload data
  Future<void> setSelectedRole(String? role) async {
    _selectedRole = role;
    await loadUsers();
  }

  /// Reset all filters to default
  Future<void> clearFilters() async {
    _searchQuery = '';
    _selectedRole = null;
    await loadUsers();
  }

  /// Retry fetching current scenario
  Future<void> retry() => loadUsers();

  /// Toggle light / dark mode
  void toggleTheme() {
    _isDarkMode = !_isDarkMode;
    notifyListeners();
  }
}
