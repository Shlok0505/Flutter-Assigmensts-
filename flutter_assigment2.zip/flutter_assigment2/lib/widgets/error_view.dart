import 'package:flutter/material.dart';
import '../services/api_exceptions.dart';

/// Error display widget showing clear error classification, status codes, and retry capability.
class ErrorView extends StatelessWidget {
  final AppException error;
  final VoidCallback onRetry;
  final VoidCallback? onResetToHealthy;

  const ErrorView({
    super.key,
    required this.error,
    required this.onRetry,
    this.onResetToHealthy,
  });

  IconData _getErrorIcon() {
    if (error is NetworkException) {
      return Icons.wifi_off_rounded;
    } else if (error is ServerException) {
      return Icons.cloud_off_rounded;
    } else if (error is ApiTimeoutException) {
      return Icons.timer_off_rounded;
    } else if (error is DataParsingException) {
      return Icons.code_off_rounded;
    }
    return Icons.error_outline_rounded;
  }

  Color _getErrorColor() {
    if (error is NetworkException) {
      return Colors.redAccent;
    } else if (error is ServerException) {
      return Colors.deepOrangeAccent;
    } else if (error is ApiTimeoutException) {
      return Colors.purpleAccent;
    } else if (error is DataParsingException) {
      return Colors.pinkAccent;
    }
    return Colors.red;
  }

  String _getErrorTitle() {
    if (error is NetworkException) {
      return 'Network Connectivity Error';
    } else if (error is ServerException) {
      return 'Server Error (HTTP 500)';
    } else if (error is ApiTimeoutException) {
      return 'Request Timed Out';
    } else if (error is DataParsingException) {
      return 'JSON Schema Parsing Error';
    }
    return 'Operation Failed';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final errorColor = _getErrorColor();

    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 32.0),
        child: Container(
          constraints: const BoxConstraints(maxWidth: 500),
          padding: const EdgeInsets.all(24.0),
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: errorColor.withValues(alpha: 0.3),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: errorColor.withValues(alpha: 0.08),
                blurRadius: 20,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Error icon in animated circle
              Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  color: errorColor.withValues(alpha: 0.12),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  _getErrorIcon(),
                  size: 36,
                  color: errorColor,
                ),
              ),
              const SizedBox(height: 16),

              // Error Code Tag
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: errorColor.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  error.code,
                  style: TextStyle(
                    fontFamily: 'Courier',
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: errorColor,
                  ),
                ),
              ),
              const SizedBox(height: 12),

              // Title
              Text(
                _getErrorTitle(),
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),

              // Error message
              Text(
                error.message,
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                  height: 1.4,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),

              // Action Buttons
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton.icon(
                    onPressed: onRetry,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: theme.colorScheme.primary,
                      foregroundColor: theme.colorScheme.onPrimary,
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    icon: const Icon(Icons.refresh_rounded, size: 18),
                    label: const Text('Retry Request'),
                  ),
                  if (onResetToHealthy != null) ...[
                    const SizedBox(width: 12),
                    OutlinedButton.icon(
                      onPressed: onResetToHealthy,
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      icon: const Icon(Icons.auto_fix_high_rounded, size: 18),
                      label: const Text('Healthy State'),
                    ),
                  ],
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
