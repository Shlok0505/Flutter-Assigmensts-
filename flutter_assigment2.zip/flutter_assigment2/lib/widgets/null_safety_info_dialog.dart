import 'package:flutter/material.dart';

/// Informational Dialog providing clear educational explanations and code snippets
/// for Dart's sound null-safety features, Future, and async/await.
class NullSafetyInfoDialog extends StatelessWidget {
  const NullSafetyInfoDialog({super.key});

  static void show(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => const NullSafetyInfoDialog(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final topics = [
      {
        'title': '1. Nullable Types (Type?)',
        'desc': 'Variables cannot be null by default. Appending `?` signals to the compiler that the value can either hold data or null.',
        'code': 'String? bio = json["bio"]; // bio can be String or null\nString name = json["name"] ?? "User"; // Non-nullable',
      },
      {
        'title': '2. Null-Coalescing Operator (??)',
        'desc': 'Provides a default fallback value whenever the expression on the left evaluates to null.',
        'code': 'String displayBio = user.bio ?? "No bio available";\nString role = user.role ?? "Community Member";',
      },
      {
        'title': '3. Safe Navigation Operator (?.)',
        'desc': 'Calls methods or accesses properties only if the object is not null. Returns null otherwise without crashing.',
        'code': 'String? city = user.address?.city;\ndouble? lat = user.address?.geo?.latitude;',
      },
      {
        'title': '4. Null Assertion Operator (!)',
        'desc': 'Informs the compiler that you guarantee the value is non-null. Use only after safe checks.',
        'code': 'if (user.hasAvatar) {\n  CircleAvatar(backgroundImage: NetworkImage(user.avatarUrl!));\n}',
      },
      {
        'title': '5. Future, async / await',
        'desc': 'Asynchronous operations return a `Future<T>`. `await` pauses execution until the future completes or throws an exception.',
        'code': 'Future<List<UserProfile>> fetchUsers() async {\n  await Future.delayed(Duration(seconds: 1));\n  return [/* ... */];\n}',
      },
      {
        'title': '6. Defensive Try / Catch / On',
        'desc': 'Handling network drops, timeouts, and server 500s cleanly without application crashes.',
        'code': 'try {\n  final users = await apiService.fetchUsers();\n} on AppException catch (e) {\n  state = ApiResponse.error(e);\n}',
      },
    ];

    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 600, maxHeight: 680),
        child: Column(
          children: [
            // Dialog Header
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.primaryContainer,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(
                      Icons.menu_book_rounded,
                      color: theme.colorScheme.primary,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Dart Null Safety & Async Guide',
                          style: theme.textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          'Key concepts implemented in this Flutter assignment',
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ],
              ),
            ),
            const Divider(height: 1),

            // Dialog List
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.all(20),
                itemCount: topics.length,
                separatorBuilder: (_, _) => const SizedBox(height: 16),
                itemBuilder: (context, index) {
                  final topic = topics[index];
                  return Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.surfaceContainerLow,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: theme.dividerColor.withValues(alpha: 0.15)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          topic['title']!,
                          style: theme.textTheme.titleSmall?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: theme.colorScheme.primary,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          topic['desc']!,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant,
                            height: 1.35,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: SelectableText(
                            topic['code']!,
                            style: const TextStyle(
                              fontFamily: 'Courier',
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
