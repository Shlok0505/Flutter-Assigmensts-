import 'package:flutter/material.dart';

/// A robust, null-safe avatar widget that displays a remote network image
/// or safely falls back to the user's initials if avatarUrl is null or fails to load.
class SafeAvatar extends StatelessWidget {
  final String? avatarUrl;
  final String initials;
  final double radius;
  final Color? backgroundColor;
  final Color? foregroundColor;
  final double fontSize;

  const SafeAvatar({
    super.key,
    required this.avatarUrl,
    required this.initials,
    this.radius = 28,
    this.backgroundColor,
    this.foregroundColor,
    this.fontSize = 18,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final bgColor = backgroundColor ?? theme.colorScheme.primaryContainer;
    final fgColor = foregroundColor ?? theme.colorScheme.onPrimaryContainer;

    // If avatarUrl is null or empty, immediately render initials fallback
    if (avatarUrl == null || avatarUrl!.trim().isEmpty) {
      return _buildInitialsCircle(bgColor, fgColor);
    }

    return CircleAvatar(
      radius: radius,
      backgroundColor: bgColor,
      child: ClipOval(
        child: Image.network(
          avatarUrl!,
          width: radius * 2,
          height: radius * 2,
          fit: BoxFit.cover,
          errorBuilder: (context, error, stackTrace) {
            // Safe fallback if network request fails or is blocked
            return _buildInitialsCircle(bgColor, fgColor);
          },
          loadingBuilder: (context, child, loadingProgress) {
            if (loadingProgress == null) return child;
            return Center(
              child: SizedBox(
                width: radius,
                height: radius,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  value: loadingProgress.expectedTotalBytes != null
                      ? loadingProgress.cumulativeBytesLoaded /
                          loadingProgress.expectedTotalBytes!
                      : null,
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildInitialsCircle(Color bgColor, Color fgColor) {
    return Container(
      width: radius * 2,
      height: radius * 2,
      decoration: BoxDecoration(
        color: bgColor,
        shape: BoxShape.circle,
      ),
      alignment: Alignment.center,
      child: Text(
        initials,
        style: TextStyle(
          fontSize: fontSize,
          fontWeight: FontWeight.bold,
          color: fgColor,
        ),
      ),
    );
  }
}
