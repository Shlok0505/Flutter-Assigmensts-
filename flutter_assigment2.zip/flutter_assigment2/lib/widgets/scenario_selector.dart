import 'package:flutter/material.dart';
import '../services/mock_api_service.dart';

/// Interactive Scenario Selector bar allowing instant switching between API response types.
class ScenarioSelector extends StatelessWidget {
  final MockScenario selectedScenario;
  final ValueChanged<MockScenario> onScenarioSelected;

  const ScenarioSelector({
    super.key,
    required this.selectedScenario,
    required this.onScenarioSelected,
  });

  IconData _getIconForScenario(MockScenario scenario) {
    switch (scenario) {
      case MockScenario.completeData:
        return Icons.check_circle_outline;
      case MockScenario.partialNullData:
        return Icons.rule_folder_outlined;
      case MockScenario.networkFailure:
        return Icons.wifi_off_outlined;
      case MockScenario.serverError:
        return Icons.dns_outlined;
      case MockScenario.timeoutError:
        return Icons.timer_outlined;
      case MockScenario.emptyResponse:
        return Icons.inbox_outlined;
      case MockScenario.malformedJson:
        return Icons.data_object_outlined;
    }
  }

  Color _getColorForScenario(MockScenario scenario, BuildContext context) {
    switch (scenario) {
      case MockScenario.completeData:
        return const Color(0xFF10B981);
      case MockScenario.partialNullData:
        return Colors.amber.shade700;
      case MockScenario.networkFailure:
        return Colors.redAccent;
      case MockScenario.serverError:
        return Colors.deepOrangeAccent;
      case MockScenario.timeoutError:
        return Colors.purpleAccent;
      case MockScenario.emptyResponse:
        return Colors.blueGrey;
      case MockScenario.malformedJson:
        return Colors.pinkAccent;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12.0),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
        border: Border(
          bottom: BorderSide(
            color: theme.dividerColor.withValues(alpha: 0.15),
          ),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 4.0),
            child: Row(
              children: [
                Icon(
                  Icons.tune_rounded,
                  size: 16,
                  color: theme.colorScheme.primary,
                ),
                const SizedBox(width: 6),
                Text(
                  'API SIMULATION SCENARIO',
                  style: theme.textTheme.labelSmall?.copyWith(
                    letterSpacing: 1.2,
                    fontWeight: FontWeight.w700,
                    color: theme.colorScheme.primary,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 6),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12.0),
            physics: const BouncingScrollPhysics(),
            child: Row(
              children: MockScenario.values.map((scenario) {
                final isSelected = scenario == selectedScenario;
                final color = _getColorForScenario(scenario, context);

                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4.0),
                  child: FilterChip(
                    showCheckmark: false,
                    selected: isSelected,
                    selectedColor: color.withValues(alpha: 0.2),
                    side: BorderSide(
                      color: isSelected ? color : theme.colorScheme.outline.withValues(alpha: 0.3),
                      width: isSelected ? 1.8 : 1.0,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    avatar: Icon(
                      _getIconForScenario(scenario),
                      size: 18,
                      color: isSelected ? color : theme.colorScheme.onSurfaceVariant,
                    ),
                    label: Text(
                      scenario.title,
                      style: TextStyle(
                        fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                        color: isSelected ? color : theme.colorScheme.onSurface,
                        fontSize: 13,
                      ),
                    ),
                    onSelected: (_) => onScenarioSelected(scenario),
                  ),
                );
              }).toList(),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 16.0, right: 16.0, top: 8.0),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0),
              decoration: BoxDecoration(
                color: _getColorForScenario(selectedScenario, context).withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: _getColorForScenario(selectedScenario, context).withValues(alpha: 0.2),
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.info_outline_rounded,
                    size: 16,
                    color: _getColorForScenario(selectedScenario, context),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      selectedScenario.description,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
