import 'package:flutter/material.dart';
import '../models/user_profile.dart';
import 'safe_avatar.dart';
import 'user_detail_sheet.dart';

/// User Profile Card component demonstrating sound null safety in presentation:
/// - Avatar image fallback to user initials when `avatarUrl == null`
/// - Safe string interpolation with `??` fallback values
/// - Safe navigation with `?.` for nested address and company models
/// - Null badge counters
class UserCard extends StatelessWidget {
  final UserProfile user;

  const UserCard({
    super.key,
    required this.user,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final hasNullFields = user.avatarUrl == null ||
        user.bio == null ||
        user.phone == null ||
        user.website == null ||
        user.rating == null ||
        user.address == null ||
        user.company == null;

    return Card(
      elevation: 2,
      margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(
          color: theme.colorScheme.outlineVariant.withValues(alpha: 0.4),
          width: 1,
        ),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => UserDetailSheet.show(context, user),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header: Avatar, Name, Verified status, Role, and Rating
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Null-Safe Avatar: Falls back to Initials Circle if URL is null
                  Hero(
                    tag: 'avatar_${user.id}',
                    child: SafeAvatar(
                      avatarUrl: user.avatarUrl,
                      initials: user.initials,
                      radius: 28,
                      fontSize: 18,
                    ),
                  ),
                  const SizedBox(width: 14),

                  // Name, Username & Role
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Flexible(
                              child: Text(
                                user.name,
                                style: theme.textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: -0.2,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            if (user.verified) ...[
                              const SizedBox(width: 6),
                              const Icon(
                                Icons.verified_rounded,
                                size: 16,
                                color: Colors.blueAccent,
                              ),
                            ],
                          ],
                        ),
                        const SizedBox(height: 2),
                        Text(
                          '@${user.username} • ${user.displayRole}',
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        const SizedBox(height: 4),
                        // Rating & Last active
                        Row(
                          children: [
                            Icon(
                              Icons.star_rounded,
                              size: 15,
                              color: user.rating != null ? Colors.amber : Colors.grey,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              user.displayRating,
                              style: theme.textTheme.labelSmall?.copyWith(
                                fontWeight: FontWeight.bold,
                                color: user.rating != null
                                    ? theme.colorScheme.onSurface
                                    : theme.colorScheme.onSurfaceVariant,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              '• ${user.displayLastActive}',
                              style: theme.textTheme.labelSmall?.copyWith(
                                color: theme.colorScheme.onSurfaceVariant,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  // Null indicators tag
                  if (hasNullFields)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.amber.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: Colors.amber.withValues(alpha: 0.4),
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.shield_outlined, size: 12, color: Colors.amber),
                          const SizedBox(width: 4),
                          Text(
                            'Nulls Handled',
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                              color: Colors.amber.shade900,
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),

              const SizedBox(height: 12),

              // Bio: demonstrates `??` fallback string
              Text(
                user.displayBio,
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: user.bio != null
                      ? theme.colorScheme.onSurface
                      : theme.colorScheme.onSurfaceVariant.withValues(alpha: 0.8),
                  fontStyle: user.bio != null ? FontStyle.normal : FontStyle.italic,
                  height: 1.35,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),

              const SizedBox(height: 12),

              // Skills Chips (if any)
              if (user.safeSkills.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10.0),
                  child: Wrap(
                    spacing: 6,
                    runSpacing: 4,
                    children: user.safeSkills.take(3).map((skill) {
                      return Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: theme.colorScheme.secondaryContainer.withValues(alpha: 0.6),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          skill,
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            color: theme.colorScheme.onSecondaryContainer,
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),

              const Divider(height: 1),
              const SizedBox(height: 10),

              // Footer Meta Info with Safe Navigation `?.` and fallback `??`
              Wrap(
                spacing: 12,
                runSpacing: 6,
                children: [
                  _buildMetaIcon(
                    icon: Icons.location_on_outlined,
                    label: user.address?.shortCity ?? 'No Location',
                    theme: theme,
                    isMissing: user.address == null,
                  ),
                  _buildMetaIcon(
                    icon: Icons.phone_outlined,
                    label: user.phone != null ? 'Phone Available' : 'No Phone',
                    theme: theme,
                    isMissing: user.phone == null,
                  ),
                  _buildMetaIcon(
                    icon: Icons.business_outlined,
                    label: user.company?.displayName ?? 'Independent',
                    theme: theme,
                    isMissing: user.company == null,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMetaIcon({
    required IconData icon,
    required String label,
    required ThemeData theme,
    required bool isMissing,
  }) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          icon,
          size: 14,
          color: isMissing
              ? theme.colorScheme.onSurfaceVariant.withValues(alpha: 0.5)
              : theme.colorScheme.primary,
        ),
        const SizedBox(width: 4),
        Text(
          label,
          style: theme.textTheme.labelSmall?.copyWith(
            color: isMissing
                ? theme.colorScheme.onSurfaceVariant.withValues(alpha: 0.6)
                : theme.colorScheme.onSurfaceVariant,
            fontSize: 11,
          ),
        ),
      ],
    );
  }
}
