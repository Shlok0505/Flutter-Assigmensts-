import 'dart:convert';
import 'package:flutter/material.dart';
import '../models/user_profile.dart';
import 'safe_avatar.dart';

/// Modal bottom sheet showcasing detailed inspection of a UserProfile object,
/// comparing raw JSON with sound null-safe parsed properties.
class UserDetailSheet extends StatelessWidget {
  final UserProfile user;

  const UserDetailSheet({
    super.key,
    required this.user,
  });

  static void show(BuildContext context, UserProfile user) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => UserDetailSheet(user: user),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final jsonEncoder = const JsonEncoder.withIndent('  ');
    final formattedJson = jsonEncoder.convert(user.toJson());

    return DraggableScrollableSheet(
      initialChildSize: 0.85,
      minChildSize: 0.5,
      maxChildSize: 0.95,
      builder: (context, scrollController) {
        return Container(
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.3),
                blurRadius: 20,
                offset: const Offset(0, -5),
              ),
            ],
          ),
          child: Column(
            children: [
              // Sheet Drag Handle
              Center(
                child: Container(
                  margin: const EdgeInsets.only(top: 12, bottom: 8),
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: theme.dividerColor,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),

              // Sheet Header
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 8.0),
                child: Row(
                  children: [
                    SafeAvatar(
                      avatarUrl: user.avatarUrl,
                      initials: user.initials,
                      radius: 24,
                      fontSize: 16,
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Flexible(
                                child: Text(
                                  user.name,
                                  style: theme.textTheme.titleMedium?.copyWith(
                                    fontWeight: FontWeight.bold,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              if (user.verified) ...[
                                const SizedBox(width: 6),
                                const Icon(Icons.verified, size: 18, color: Colors.blue),
                              ],
                            ],
                          ),
                          Text(
                            '@${user.username} • ${user.displayRole}',
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: theme.colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ],
                ),
              ),
              const Divider(),

              // Scrollable Content
              Expanded(
                child: ListView(
                  controller: scrollController,
                  padding: const EdgeInsets.all(20),
                  children: [
                    // Null Safety Analysis Card
                    _buildNullSafetyCard(context),
                    const SizedBox(height: 16),

                    // Profile Details Section
                    _buildSectionTitle(context, 'Profile Attributes & Null-Safe Getters'),
                    const SizedBox(height: 8),
                    _buildInfoRow(
                      context,
                      'Email (non-nullable)',
                      user.email,
                      isNullable: false,
                    ),
                    _buildInfoRow(
                      context,
                      'Bio (nullable: String?)',
                      user.bio ?? 'null -> Fallback: "${user.displayBio}"',
                      isFallback: user.bio == null,
                    ),
                    _buildInfoRow(
                      context,
                      'Phone (nullable: String?)',
                      user.phone ?? 'null -> Fallback: "${user.displayPhone}"',
                      isFallback: user.phone == null,
                    ),
                    _buildInfoRow(
                      context,
                      'Website (nullable: String?)',
                      user.website ?? 'null -> Fallback: "${user.displayWebsite}"',
                      isFallback: user.website == null,
                    ),
                    _buildInfoRow(
                      context,
                      'Rating (nullable: double?)',
                      user.rating != null ? '${user.rating} / 5.0' : 'null -> Fallback: "Unrated"',
                      isFallback: user.rating == null,
                    ),
                    _buildInfoRow(
                      context,
                      'Address (nullable: Address?)',
                      user.address != null
                          ? user.address!.fullAddress
                          : 'null -> Safely handled via `user.address?.fullAddress`',
                      isFallback: user.address == null,
                    ),
                    _buildInfoRow(
                      context,
                      'Company (nullable: Company?)',
                      user.company != null
                          ? user.company!.displayName
                          : 'null -> Safely handled via `user.company?.displayName`',
                      isFallback: user.company == null,
                    ),
                    _buildInfoRow(
                      context,
                      'Skills (nullable: List<String>?)',
                      user.skills != null && user.skills!.isNotEmpty
                          ? user.skills!.join(', ')
                          : 'null / empty -> Fallback: `user.skills ?? []`',
                      isFallback: user.skills == null || user.skills!.isEmpty,
                    ),

                    const SizedBox(height: 20),
                    _buildSectionTitle(context, 'Raw Simulated JSON Payload'),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: theme.dividerColor.withValues(alpha: 0.3)),
                      ),
                      child: SelectableText(
                        formattedJson,
                        style: const TextStyle(
                          fontFamily: 'Courier',
                          fontSize: 12,
                          height: 1.4,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildNullSafetyCard(BuildContext context) {
    final theme = Theme.of(context);
    final nullCount = [
      user.avatarUrl,
      user.bio,
      user.phone,
      user.website,
      user.rating,
      user.role,
      user.isVerified,
      user.skills,
      user.address,
      user.company,
      user.lastActive,
    ].where((val) => val == null).length;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            theme.colorScheme.primaryContainer.withValues(alpha: 0.7),
            theme.colorScheme.secondaryContainer.withValues(alpha: 0.7),
          ],
        ),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.shield_outlined, color: theme.colorScheme.primary),
              const SizedBox(width: 8),
              Text(
                'Null Safety Protection Active',
                style: theme.textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: theme.colorScheme.onPrimaryContainer,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            nullCount == 0
                ? 'All fields are fully populated in this record. Zero runtime null issues.'
                : '$nullCount nullable fields in this profile are currently null. Dart null safety and default coalescing operators (`??`, `?.`) prevented null pointer exceptions.',
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onPrimaryContainer,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(BuildContext context, String title) {
    final theme = Theme.of(context);
    return Text(
      title,
      style: theme.textTheme.titleSmall?.copyWith(
        fontWeight: FontWeight.bold,
        color: theme.colorScheme.primary,
      ),
    );
  }

  Widget _buildInfoRow(
    BuildContext context,
    String label,
    String value, {
    bool isNullable = true,
    bool isFallback = false,
  }) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6.0),
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: isFallback
              ? Colors.amber.withValues(alpha: 0.08)
              : theme.colorScheme.surfaceContainerLow,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: isFallback
                ? Colors.amber.withValues(alpha: 0.3)
                : theme.dividerColor.withValues(alpha: 0.1),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  label,
                  style: theme.textTheme.labelSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: isFallback ? Colors.amber.shade800 : theme.colorScheme.onSurfaceVariant,
                  ),
                ),
                const Spacer(),
                if (isFallback)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.amber.withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: const Text(
                      'NULL FALLBACK',
                      style: TextStyle(
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                        color: Colors.amber,
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              value,
              style: TextStyle(
                fontSize: 13,
                fontWeight: isFallback ? FontWeight.normal : FontWeight.w500,
                color: isFallback ? theme.colorScheme.onSurface : theme.colorScheme.onSurface,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
