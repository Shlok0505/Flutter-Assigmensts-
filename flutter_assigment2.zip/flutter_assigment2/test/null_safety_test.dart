import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_assigment2/models/api_response.dart';
import 'package:flutter_assigment2/models/user_profile.dart';
import 'package:flutter_assigment2/services/api_exceptions.dart';
import 'package:flutter_assigment2/services/mock_api_service.dart';
import 'package:flutter_assigment2/state/user_controller.dart';

void main() {
  group('Sound Null Safety & Model Tests', () {
    test('UserProfile.fromJson handles full JSON payload correctly', () {
      final json = {
        'id': 101,
        'name': 'Alex Vance',
        'username': 'alexv',
        'email': 'alex@test.com',
        'avatarUrl': 'https://example.com/avatar.jpg',
        'bio': 'Software Engineer',
        'phone': '+1 555 1234',
        'website': 'https://alex.dev',
        'rating': 4.9,
        'role': 'Engineer',
        'isVerified': true,
        'skills': ['Flutter', 'Dart'],
        'address': {
          'street': 'Main St',
          'suite': 'Apt 1',
          'city': 'San Francisco',
          'zipcode': '94105',
          'geo': {'lat': 37.77, 'lng': -122.41},
        },
        'company': {
          'name': 'Acme Corp',
          'catchPhrase': 'Leading innovation',
          'bs': 'solutions',
        },
        'lastActive': '2026-09-19T10:00:00.000Z',
      };

      final user = UserProfile.fromJson(json);

      expect(user.id, 101);
      expect(user.name, 'Alex Vance');
      expect(user.username, 'alexv');
      expect(user.email, 'alex@test.com');
      expect(user.hasAvatar, isTrue);
      expect(user.avatarUrl, 'https://example.com/avatar.jpg');
      expect(user.bio, 'Software Engineer');
      expect(user.displayBio, 'Software Engineer');
      expect(user.phone, '+1 555 1234');
      expect(user.displayPhone, '+1 555 1234');
      expect(user.website, 'https://alex.dev');
      expect(user.displayWebsite, 'https://alex.dev');
      expect(user.rating, 4.9);
      expect(user.displayRating, '4.9');
      expect(user.verified, isTrue);
      expect(user.safeSkills, containsAll(['Flutter', 'Dart']));
      expect(user.address?.shortCity, 'San Francisco');
      expect(user.address?.geo?.hasCoordinates, isTrue);
      expect(user.company?.displayName, 'Acme Corp');
      expect(user.initials, 'AV');
    });

    test('UserProfile.fromJson safely handles null and missing fields with ?? fallbacks', () {
      final json = <String, dynamic>{
        'id': 202,
        'name': 'Jordan Rivera',
        'username': 'jordan',
        'email': 'jordan@test.com',
        'avatarUrl': null,
        'bio': null,
        'phone': null,
        'website': null,
        'rating': null,
        'role': null,
        'isVerified': null,
        'skills': null,
        'address': null,
        'company': null,
        'lastActive': null,
      };

      final user = UserProfile.fromJson(json);

      expect(user.id, 202);
      expect(user.name, 'Jordan Rivera');
      expect(user.hasAvatar, isFalse);
      expect(user.initials, 'JR');
      // Verify null-coalescing fallbacks
      expect(user.displayBio, contains('No biography provided'));
      expect(user.displayPhone, 'No contact phone provided');
      expect(user.displayWebsite, 'No website listed');
      expect(user.displayRating, 'Unrated');
      expect(user.displayRole, 'Community Member');
      expect(user.verified, isFalse);
      expect(user.safeSkills, isEmpty);
      // Safe navigation on null nested objects
      expect(user.address?.fullAddress, isNull);
      expect(user.address?.shortCity, isNull);
      expect(user.company?.displayName, isNull);
      expect(user.displayLastActive, 'Active status unknown');
    });
  });

  group('MockApiService Asynchronous Scenarios & Error Handling', () {
    late MockApiService apiService;

    setUp(() {
      apiService = MockApiService();
    });

    test('fetchUsers with completeData returns non-empty list', () async {
      final users = await apiService.fetchUsers(
        scenario: MockScenario.completeData,
        delay: Duration.zero,
      );

      expect(users, isNotEmpty);
      expect(users.first.name, 'Alexandria Vance');
    });

    test('fetchUsers with partialNullData returns users with null values safely', () async {
      final users = await apiService.fetchUsers(
        scenario: MockScenario.partialNullData,
        delay: Duration.zero,
      );

      expect(users, isNotEmpty);
      final nullUser = users.firstWhere((u) => u.id == 201);
      expect(nullUser.avatarUrl, isNull);
      expect(nullUser.bio, isNull);
      expect(nullUser.phone, isNull);
    });

    test('fetchUsers with networkFailure throws NetworkException', () async {
      expect(
        () => apiService.fetchUsers(
          scenario: MockScenario.networkFailure,
          delay: Duration.zero,
        ),
        throwsA(isA<NetworkException>()),
      );
    });

    test('fetchUsers with serverError throws ServerException with status 500', () async {
      expect(
        () => apiService.fetchUsers(
          scenario: MockScenario.serverError,
          delay: Duration.zero,
        ),
        throwsA(predicate((e) => e is ServerException && e.statusCode == 500)),
      );
    });

    test('fetchUsers with timeoutError throws ApiTimeoutException', () async {
      expect(
        () => apiService.fetchUsers(
          scenario: MockScenario.timeoutError,
          delay: Duration.zero,
        ),
        throwsA(isA<ApiTimeoutException>()),
      );
    });

    test('fetchUsers with malformedJson throws DataParsingException', () async {
      expect(
        () => apiService.fetchUsers(
          scenario: MockScenario.malformedJson,
          delay: Duration.zero,
        ),
        throwsA(isA<DataParsingException>()),
      );
    });

    test('fetchUsers with emptyResponse returns empty list', () async {
      final users = await apiService.fetchUsers(
        scenario: MockScenario.emptyResponse,
        delay: Duration.zero,
      );

      expect(users, isEmpty);
    });
  });

  group('UserController State Management & Async Flow', () {
    late UserController controller;

    setUp(() {
      controller = UserController();
    });

    test('Initial state transitions properly on loadUsers', () async {
      expect(controller.state.status, ApiStatus.idle);

      final loadFuture = controller.loadUsers(scenario: MockScenario.completeData);
      expect(controller.state.isLoading, isTrue);

      await loadFuture;

      expect(controller.state.isSuccess, isTrue);
      expect(controller.state.data, isNotNull);
      expect(controller.state.data!.length, greaterThan(0));
    });

    test('Handles error scenario gracefully and updates state to error', () async {
      await controller.loadUsers(scenario: MockScenario.networkFailure);

      expect(controller.state.isError, isTrue);
      expect(controller.state.error, isA<NetworkException>());
    });

    test('Search filtering filters users by name', () async {
      await controller.loadUsers(scenario: MockScenario.completeData);
      await controller.setSearchQuery('Marcus');

      expect(controller.state.isSuccess, isTrue);
      expect(controller.state.data!.length, 1);
      expect(controller.state.data!.first.name, 'Marcus Chen');
    });

    test('Role filtering filters users by role', () async {
      await controller.loadUsers(scenario: MockScenario.completeData);
      await controller.setSelectedRole('Lead UI/UX Designer');

      expect(controller.state.isSuccess, isTrue);
      expect(controller.state.data!.length, 1);
      expect(controller.state.data!.first.name, 'Elena Rostova');
    });
  });
}
