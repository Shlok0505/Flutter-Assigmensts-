import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_assigment2/main.dart';
import 'package:flutter_assigment2/widgets/scenario_selector.dart';
import 'package:flutter_assigment2/widgets/user_card.dart';

void main() {
  testWidgets('Renders MockApiApp dashboard with scenario selector and search bar', (WidgetTester tester) async {
    // Set a large screen size for test environment
    tester.view.physicalSize = const Size(1200, 1800);
    tester.view.devicePixelRatio = 1.0;
    addTearDown(() => tester.view.resetPhysicalSize());

    // Build our app and trigger a frame.
    await tester.pumpWidget(const MockApiApp());

    // Verify AppBar title
    expect(find.text('Async Mock API'), findsOneWidget);
    expect(find.text('Sound Null Safety & Error Handling'), findsOneWidget);

    // Verify Scenario Selector is rendered
    expect(find.byType(ScenarioSelector), findsOneWidget);
    expect(find.text('Complete Data'), findsOneWidget);
    expect(find.text('Nullable / Partial Data'), findsOneWidget);
    expect(find.text('Network Failure'), findsOneWidget);

    // Verify Search bar exists
    expect(find.byType(TextField), findsOneWidget);

    // Wait for async load to finish
    await tester.pumpAndSettle();

    // Verify UserCards are rendered
    expect(find.byType(UserCard), findsWidgets);
    expect(find.text('Alexandria Vance'), findsOneWidget);
  });
}
